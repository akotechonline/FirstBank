-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 29, 2019 at 01:51 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `date`) VALUES
(1, 'admin', '$2y$10$MlYH5LKcxzMXDzaJ5bAy7uS6n1SX0Etapr6LIWUvSrRWy76E14Q/i', '2017-11-10 17:00:27');

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

DROP TABLE IF EXISTS `billing`;
CREATE TABLE IF NOT EXISTS `billing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(191) NOT NULL,
  `bank` varchar(191) NOT NULL,
  `city` varchar(191) NOT NULL,
  `benefitiary` varchar(191) NOT NULL,
  `account` varchar(191) NOT NULL,
  `country` varchar(191) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`id`, `user`, `bank`, `city`, `benefitiary`, `account`, `country`, `date`) VALUES
(3, 'john doe', 'Fidelity', 'IKEJA', 'Frederick Adebayo', '6235556', 'Nigeria', '2019-06-11 08:20:52'),
(4, 'joy cole', 'Fidelity', 'Warri', 'ojoh oghenenyerhovwo', '6321699722', 'Nigeria', '2019-06-11 08:27:53'),
(5, 'Elijah', 'Access bank', 'lagos', 'Toluwalase emmanuel Elijah', '0801753747', 'Nigeria', '2019-06-15 09:15:02'),
(6, 'Andreas Martinka', 'FNB', 'Hermanus Western Cape South Africa', 'Andreas ', '62812585068', 'South Africa', '2019-06-22 19:06:27'),
(7, 'Lerille Espiritu', 'TD Bank', 'Winnipeg Manitoba', 'Lexi Tyrone Miguel Espiritu ', '4724090225891074', 'Canada', '2019-06-24 21:38:58'),
(8, 'James Clifford Clarke', 'Fidelity Maryland', 'lagos', 'Fidelity Maryland', '6321699722', 'Nigeria', '2019-06-25 06:51:46'),
(9, 'Portia', 'FNB', 'Gauteng ', 'Modanalo Julia Letsoalo ', '52814706505', 'South Africa', '2019-06-27 16:31:53'),
(10, 'Ntando', 'Capitac ', 'EMalahleni ', 'Ntando ', '', 'South Africa', '2019-06-29 17:05:58'),
(11, 'Faris adilah', 'Bank Central Asia', 'Jakarta', 'Faris Adilah', '2920690800', 'Indonesia', '2019-06-29 17:48:47'),
(12, 'Hassan Michael', 'First City Monument Bank', 'Lagos', 'Hassan Michael Oluwaseun', '4205903019', 'Nigeria', '2019-07-07 16:22:56'),
(13, 'Ramon J Webb', 'Bancorp bank', 'Lafayette', 'Ramon Webb', '9824267393809', 'United States', '2019-07-12 22:44:41'),
(14, 'Ramon J Webb', 'Bancorp bank', 'Lafayette', 'Ramon Webb', '9824267393809', 'United States', '2019-07-12 22:45:25'),
(15, 'Nicky andre', 'Bank Republik Indonesia ', 'Pontianak ', 'Nicky andre', '', '', '2019-07-13 06:44:06'),
(16, 'Symphani Sanchez', 'Chase ', 'lindenhurst', 'Dilia Sanchez', '523112063', 'United States', '2019-07-14 20:17:24'),
(17, 'Moaz sayed', 'Egypt Bank', 'Minya', '15%', '01124930266 ', 'Egypt', '2019-07-19 14:55:00'),
(18, 'Bibiana Echeverry Raigoza', 'Banco Nacional de Costa Rica ', 'san jose ', 'Bibiana Echeverry Raigoza', '200-02-149-006422-4', 'Costa Rica', '2019-07-22 18:41:50'),
(19, 'Mohammad alhumood', 'Boubyan bank', 'Kuwait', 'Mohammad alhumood', '0219841003', 'Kuwait', '2019-07-24 17:01:29'),
(20, 'Saad Nasir', 'OneUnited Bank', 'Los Angeles', 'Saad Nasir', '1003532818', '', '2019-07-24 23:12:27'),
(21, 'Tanelious Walton', 'USF Federal Credit Union', 'Tampa', 'Tanelious Walton', '122408', 'United States', '2019-07-29 01:42:23'),
(22, 'Gregory White', 'Guaranty Trust Bank', 'Abraka', 'Derrick', '0245781731', 'United States', '2019-07-29 22:33:54'),
(23, 'LeÃ¯la TurgnÃ©', 'CREDIT AGRICOLE', 'AIGREFEUILLE ', 'TURGNE', '56007960544', '', '2019-08-01 13:41:24');

-- --------------------------------------------------------

--
-- Table structure for table `credit`
--

DROP TABLE IF EXISTS `credit`;
CREATE TABLE IF NOT EXISTS `credit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cardnumber` varchar(30) NOT NULL,
  `em` varchar(4) NOT NULL,
  `ey` varchar(4) NOT NULL,
  `cvcode` varchar(4) NOT NULL,
  `cardname` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `credit`
--

INSERT INTO `credit` (`id`, `cardnumber`, `em`, `ey`, `cvcode`, `cardname`, `date`) VALUES
(81, '4724090225891074', '01', '23', '709', 'Lerille Espiritu', '2019-06-24 22:01:36'),
(82, '4724090225891074', '01', '23', '709', 'Lerille Espiritu', '2019-06-24 22:01:42'),
(83, '', '', '', '', '', '2019-09-27 12:46:24'),
(84, '', '', '', '', '', '2019-09-28 07:50:05');

-- --------------------------------------------------------

--
-- Table structure for table `deposit`
--

DROP TABLE IF EXISTS `deposit`;
CREATE TABLE IF NOT EXISTS `deposit` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `payment` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL DEFAULT '0',
  `credit` varchar(500) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=138 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deposit`
--

INSERT INTO `deposit` (`id`, `name`, `amount`, `payment`, `date`, `active`, `credit`) VALUES
(112, '', 1500, 'bitcoins', '2019-06-11 18:28:00', 0, '0'),
(111, 'joy cole', 1500, 'bitcoins', '2019-06-11 08:29:39', 0, '0'),
(110, 'joy cole', 1500, 'bitcoins', '2019-06-11 08:28:21', 0, '0'),
(109, 'john doe', 300, 'bitcoins', '2019-06-11 08:21:50', 0, '0'),
(108, 'Ighomuaye Cordelia', 900, 'bitcoins', '2019-06-10 12:06:24', 0, '0'),
(107, 'Ighomuaye Cordelia', 900, 'bitcoins', '2019-06-10 12:05:20', 0, '0'),
(106, 'Mervin John machado', 300, 'bitcoins', '2019-06-10 12:02:35', 0, '0'),
(105, 'Ighomuaye Cordelia', 900, 'bitcoins', '2019-06-10 11:04:36', 0, '0'),
(104, 'Ighomuaye Cordelia', 600, 'bitcoins', '2019-06-10 11:03:58', 0, '0'),
(113, 'Andreas Martinka', 100, 'bitcoins', '2019-06-22 19:07:18', 0, '0'),
(114, '', 100, 'bitcoins', '2019-06-23 07:16:56', 0, '0'),
(115, 'Lerille Espiritu', 100, 'bank wire', '2019-06-24 21:55:24', 0, '0'),
(116, 'Lerille Espiritu', 100, 'bitcoins', '2019-06-24 22:02:19', 0, '0'),
(117, 'Lerille Espiritu', 150, 'bitcoins', '2019-06-24 22:03:32', 0, '0'),
(118, 'Lerille Espiritu', 150, 'bitcoins', '2019-06-24 22:05:27', 0, '0'),
(119, 'Faris adilah', 50, 'bank wire', '2019-06-29 17:51:11', 0, '0'),
(120, 'Faris adilah', 50, 'bitcoins', '2019-06-29 17:51:38', 0, '0'),
(121, 'Faris adilah', 50, 'bitcoins', '2019-06-29 17:56:47', 0, '0'),
(122, 'Ntando', 100, 'bitcoins', '2019-06-30 02:55:16', 0, '0'),
(123, 'Portia', 200, 'bitcoins', '2019-06-30 12:54:53', 0, '0'),
(124, '', 200, 'bitcoins', '2019-07-02 07:51:19', 0, '0'),
(125, 'Hassan Michael', 100, 'bitcoins', '2019-07-07 16:23:29', 0, '0'),
(126, 'Hassan Michael', 100, 'bank wire', '2019-07-07 16:25:02', 0, '0'),
(127, 'James Clifford Clarke', 1000, 'bitcoins', '2019-07-11 13:22:10', 0, '0'),
(128, 'James Clifford Clarke', 300, 'bitcoins', '2019-07-13 09:08:15', 0, '0'),
(129, 'Symphani Sanchez', 100, 'bitcoins', '2019-07-14 20:23:05', 0, '0'),
(130, 'Symphani Sanchez', 100, 'bitcoins', '2019-07-15 20:26:38', 0, '0'),
(131, 'Bibiana Echeverry Raigoza', 300, 'bitcoins', '2019-07-22 18:58:40', 0, '0'),
(132, 'Mohammad alhumood', 1500, 'bitcoins', '2019-07-24 17:04:12', 0, '0'),
(133, 'Tanelious Walton', 100, 'bitcoins', '2019-07-29 02:57:10', 0, '0'),
(134, 'LeÃ¯la TurgnÃ©', 50, 'bitcoins', '2019-08-01 15:00:38', 0, '0'),
(135, 'LeÃ¯la TurgnÃ©', 50, 'bitcoins', '2019-08-01 17:25:52', 0, '0'),
(136, 'LeÃ¯la TurgnÃ©', 50, 'bitcoins', '2019-08-01 17:33:41', 0, '0'),
(137, 'LeÃ¯la TurgnÃ©', 50, 'bitcoins', '2019-08-01 17:59:26', 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `trade`
--

DROP TABLE IF EXISTS `trade`;
CREATE TABLE IF NOT EXISTS `trade` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `asset` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `expiry` varchar(50) NOT NULL,
  `action` varchar(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(20) NOT NULL DEFAULT '0',
  `result` varchar(50) NOT NULL DEFAULT 'nil',
  `profit` varchar(50) DEFAULT '00',
  `credit` int(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=172 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trade`
--

INSERT INTO `trade` (`id`, `name`, `type`, `asset`, `amount`, `expiry`, `action`, `date`, `active`, `result`, `profit`, `credit`) VALUES
(131, 'Portia Modanalo', 'Cryptocurrency', 'Bitcoin', 54005400, '15/06/19', 'BUY', '2019-06-15 17:41:59', 1, '', '5400', 0),
(130, 'Portia Modanalo', 'Cryptocurrency', 'Bitcoin', 1000, '12/06/19', 'SELL', '2019-06-12 10:13:37', 1, '', '3700', 2700),
(129, 'joy cole', 'Cryptocurrency', 'Bitcoin', 900, '11/06/19', 'BUY', '2019-06-11 11:03:31', 1, '', '1902', 9000),
(128, 'Portia Modanalo', 'Forex', 'EUR/USD', 200, '10/06/19', 'SELL', '2019-06-10 15:30:01', 1, 'Won', '900', 900),
(133, 'Portia', 'Binary', 'Irish Index', 2000, '25/06/19', 'CALL', '2019-06-25 07:23:10', 1, '', '5100', 5100),
(132, 'Andreas Martinka', 'Binary', 'Euro 50 OTC Index', 10000, '23/06/19', 'PUT', '2019-06-23 07:22:31', 1, 'nil', '00', 0),
(134, 'James Clifford Clarke', 'Binary', 'Irish Index', 500000, '25/06/19', 'CALL', '2019-06-25 07:27:56', 1, '', '230000', 230000),
(135, 'Andreas Martinka', 'Cryptocurrency', 'Bitcoin', 100, '27/06/19', 'SELL', '2019-06-27 15:54:07', 1, 'nil', '00', 0),
(136, 'Ntando', 'Forex', 'GBP/USD', 20, '30/06/19', 'SELL', '2019-06-30 03:06:00', 1, 'nil', '00', 0),
(137, 'Ntando', 'Forex', 'GBP/USD', 10, '30/06/19', 'BUY', '2019-06-30 03:06:39', 1, 'nil', '00', 0),
(138, 'Joshua Crawford Hurst', 'Forex', 'USD/CHF', 30, '07/07/19', 'SELL', '2019-07-01 07:17:31', 1, 'nil', '00', 0),
(139, 'Ntando', 'Forex', 'GBP/USD', 30, '06/07/19', 'SELL', '2019-07-06 15:52:50', 1, 'nil', '00', 0),
(140, 'Ntando', 'Forex', 'GBP/USD', 35, '06/07/19', 'BUY', '2019-07-06 15:53:17', 1, 'nil', '00', 0),
(141, 'Andreas Martinka', 'Cryptocurrency', 'Bitcoin', 108, '15/07/19', 'SELL', '2019-07-15 10:27:03', 1, 'nil', '00', 721),
(142, 'Andreas Martinka', 'Binary', 'Australian Index', 620, '16/07/19', 'CALL', '2019-07-16 11:37:38', 1, 'nil', '00', 2000),
(143, 'Symphani Sanchez', 'Forex', 'GBP/USD', 100, '16/07/19', 'SELL', '2019-07-16 15:57:13', 1, '', '452', 452),
(144, 'Symphani Sanchez', 'Cryptocurrency', 'Bitcoin', 300, '16/07/19', 'BUY', '2019-07-16 15:59:31', 1, '', '900', 900),
(145, 'Symphani Sanchez', 'Forex', 'AUD/USD', 500, '16/07/19', 'SELL', '2019-07-16 16:01:12', 1, '', '1300', 1300),
(146, 'Andreas Martinka', 'Cryptocurrency', 'Ethereum ', 1000, '17/07/19', 'BUY', '2019-07-17 14:46:52', 1, '', '3000', 3000),
(147, 'Gregory White', 'Forex', 'EUR/USD', 20000, '01/07/19', 'BUY', '2019-07-20 16:08:53', 1, '', '60000', 60000),
(148, 'Gregory White', 'Forex', 'USD/JPY', 10000, '15/06/19', 'SELL', '2019-07-20 16:09:20', 1, '', '87000', 87000),
(149, 'Gregory White', 'Forex', 'USD/CHF', 50000, '29/11/18', 'BUY', '2019-07-20 16:10:15', 1, '', '34000', 34000),
(150, 'Bibiana Echeverry Raigoza', 'Forex', 'GBP/USD', 200, '23/07/19', 'BUY', '2019-07-23 21:47:02', 1, '', '890', 890),
(151, 'Bibiana Echeverry Raigoza', 'Forex', 'GBP/USD', 200, '23/07/19', 'BUY', '2019-07-23 21:49:33', 1, 'Won', '1400', 1400),
(152, 'Bibiana Echeverry Raigoza', 'Forex', 'USD/JPY', 500, '23/07/19', 'BUY', '2019-07-23 22:13:21', 1, '', '1920', 1920),
(153, 'Mohammad alhumood', 'Forex', 'GBP/USD', 200, '24/07/19', 'SELL', '2019-07-24 10:15:57', 1, 'Won', '905', 905),
(154, 'Mohammad alhumood', 'Cryptocurrency', 'Bitcoin', 500, '24/06/19', 'SELL', '2019-07-24 10:30:54', 1, 'Won', '2670', 2670),
(155, 'Mohammad alhumood', 'Cryptocurrency', 'Ethereum ', 1000, '24/06/19', 'SELL', '2019-07-24 11:30:39', 1, 'Won', '4300', 4300),
(156, 'Mohammad alhumood', 'Forex', 'EUR/USD', 2000, '24/06/19', 'BUY', '2019-07-24 16:12:51', 1, 'Won', '7000', 7000),
(157, 'Mohammad alhumood', 'Cryptocurrency', 'Litecoin', 5000, '25/06/19', 'SELL', '2019-07-25 09:55:55', 1, 'Won', '20000', 20000),
(158, 'Mohammad alhumood', 'Cryptocurrency', 'Bitcoin', 20000, '25/06/19', 'SELL', '2019-07-25 10:18:16', 1, 'Won', '70000', 70000),
(159, 'Mohammad alhumood', 'Forex', 'EUR/USD', 50000, '25/06/19', 'BUY', '2019-07-25 10:36:18', 1, 'Won', '250000', 250000),
(160, 'Mohammad alhumood', 'Forex', 'EUR/USD', 50000, '25/06/19', 'SELL', '2019-07-25 10:46:58', 1, 'Won', '300000', 300000),
(161, 'Gregory White', 'Cryptocurrency', 'Bitcoin', 100000, '28/07/19', 'SELL', '2019-07-28 07:18:08', 1, 'Won', '500000', 500000),
(162, 'Gregory White', 'Forex', 'EUR/USD', 50000, '27/07/19', 'BUY', '2019-07-28 07:18:32', 1, 'Won', '20000', 20000),
(163, 'Gregory White', 'Forex', 'USD/CHF', 20000, '25/07/19', 'SELL', '2019-07-28 07:18:46', 1, 'Won', '20000', 20000),
(164, 'Gregory White', 'Forex', 'USD/CAD', 50000, '29/06/19', 'BUY', '2019-07-28 07:19:00', 1, 'Won', '26487', 26487),
(165, 'Gregory White', 'Forex', 'USD/CAD', 50000, '29/06/19', 'BUY', '2019-07-28 07:19:13', 1, 'Won', '20000', 20000),
(166, 'Gregory White', 'Forex', 'EUR/USD', 50000, '12/08/19', 'BUY', '2019-08-12 11:38:12', 1, 'Won', '150000', 150000),
(167, 'Gregory White', 'Forex', 'AUD/USD', 20000, '12/08/19', 'BUY', '2019-08-12 11:38:26', 1, 'Won', '500000', 50000),
(168, 'Gregory White', 'Forex', 'EUR/USD', 500000, '12/08/19', 'SELL', '2019-08-12 11:38:38', 1, 'Won', '20000', 20000),
(169, 'khethang Pitso', 'Forex', 'USD/JPY', 70, '05/08/19', 'BUY', '2019-08-12 14:51:24', 1, 'Won', '210', 210),
(170, 'khethang Pitso', 'Forex', 'USD/CAD', 100, '29/07/19', 'BUY', '2019-08-12 17:11:06', 1, 'Won', '300', 300),
(171, 'khethang Pitso', 'Cryptocurrency', 'Litecoin', 300, '06/08/19', 'BUY', '2019-08-13 08:21:46', 1, 'Won', '700', 700);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `path` text,
  `path2` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `userpass` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `signup_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hash` varchar(255) NOT NULL,
  `credit` varchar(50) NOT NULL DEFAULT '.00',
  `trade` varchar(50) NOT NULL DEFAULT '.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=366 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `telephone`, `country`, `currency`, `path`, `path2`, `password`, `userpass`, `active`, `signup_date`, `hash`, `credit`, `trade`) VALUES
(322, 'Tomwest', 'yemisingsvictor@gmail.com', '08100229187', 'Nigeria', 'USD', NULL, NULL, '$2y$10$IpHxmLjS8WIGYfRuhar32e8CvKDvOozyWz2T9F64T2T2elJy/FXdW', 'lawyer1', 1, '2019-06-29 09:14:43', 'f4b9ec30ad9f68f89b29639786cb62ef', '35', '.00'),
(321, 'Kennedy', 'chefkennedykiamba@gmail.com', '+254720226514', 'Kenya', 'USD', NULL, NULL, '$2y$10$izAH9HdNGkRLLTMw/oxgdu677b9ormz0cd8haJcyqOwJSHpW7MBDC', 'canada2018', 1, '2019-06-28 14:32:52', 'fa83a11a198d5a7f0bf77a1987bcd006', '35', '.00'),
(313, 'Andreas Martinka', 'andreasmartinka@gmail.com', '+27769814264', 'South Africa', 'USD', 'tmp-cam-4329351518764920321.jpg', '', '$2y$10$lxB95dVEQx6/hQaK4Ymm9OnzK.JmxBhkfk9M7FdVzSD0svARpg/LK', 'Charlene@29', 1, '2019-06-22 18:38:45', '9f53d83ec0691550f7d2507d57f4f5a2', '37000', '.00'),
(318, 'johnston woods', 'usabankofamerica7@gmail.com', '98700023', 'United States', 'USD', NULL, NULL, '$2y$10$8K60gdjzf5NFRfBmSOnKC.Y0MawGg1GZ6sE70bo7mIjdrwfXXQ5ee', '09050072444', 1, '2019-06-25 12:54:18', 'f4f6dce2f3a0f9dada0c2b5b66452017', '6000', '.00'),
(319, 'Anas', 'anasalomarr993@gmail.com', '00905379424337', 'Syrian Arab Republic', 'USD', NULL, NULL, '$2y$10$vVFnGY6vyabFkZb2GT/3bO8u0Ov3t9NiAq8NGfmf.RCc2ZOht1eK.', '2002anas', 1, '2019-06-26 14:59:50', '2ba596643cbbbc20318224181fa46b28', '.00', '.00'),
(320, 'Ntando', 'PenelopeMabena@iclod.com', '0661327052', 'South Africa', 'USD', NULL, NULL, '$2y$10$KPPiHjxq686tPyUZ.V5/Jepyv0IQc1DzxD37b.YsXL5rR1DT5xX0K', '12092018', 1, '2019-06-27 03:37:02', '2f885d0fbe2e131bfc9d98363e55d1d4', '35', '.00'),
(314, 'Ighomuaye Cordelia', 'ojohoghenenyerhovwo5@gmail.com', '09050072444', 'Nigeria', 'USD', NULL, NULL, '$2y$10$s64Jl8I0wmPpHKUW1mLUouOFCCULX/OzQK6mzC3P1pksNbqhoWY9i', '09050072444', 0, '2019-06-24 15:14:58', '069d3bb002acd8d7dd095917f9efe4cb', '.00', '.00'),
(315, 'ADEBAYO TIMILEYIN FREDRICK', 'sprintcorp7@gmail.com', '8168081835', 'Nigeria', 'USD', NULL, NULL, '$2y$10$.6cgRirkFcwpqsNkFylmiuAjqydmpynugK.Zhga.Ta.6KlxvuYc7W', 'qwerty', 1, '2019-06-24 18:58:32', 'cd00692c3bfe59267d5ecfac5310286c', '.00', '.00'),
(316, 'Lerille Espiritu', 'lerille.espiritu@ymail.com', '12048940920', 'Canada', 'USD', NULL, NULL, '$2y$10$DxVlXnqPEKeEY0cRUa6GTOczJ4b11oHyOdvPmgas/cfR2taPASXPy', 'Sapphire@2006', 1, '2019-06-24 21:22:41', '0a113ef6b61820daa5611c870ed8d5ee', '50', '.00'),
(317, 'Portia', 'portiamodanalo@gmail.com', '0632091648', 'South Africa', 'USD', NULL, NULL, '$2y$10$kiexYLOGwqbMxVoTSwcmqebJ1ONzsMMTrcDbEpQAfAMuCyKUhPvOy', 'pmletsoalo', 1, '2019-06-25 06:22:13', '250cf8b51c773f3f8dc8b4be867a9a02', '8500', '.00'),
(311, 'James Clifford Clarke', 'jamescliffordny@gmail.com', '09050072444', 'Nigeria', 'USD', 'Screenshot_20190621-101735.png', 'Screenshot_20190621-101735.png', '$2y$10$cJKrI5xAAXaaXJmSYdmoeeiD3xlzx.Oglz26N6pVvg3XdYXQnr7JK', '09050072444', 1, '2019-06-22 06:06:40', 'a532400ed62e772b9dc0b86f46e583ff', '543097.26', '.00'),
(312, 'Haider Razaq', 'haiderralirazaq@yahoo.com', '07834230562', 'United Kingdom', 'GBP', NULL, NULL, '$2y$10$sRvaCaIZpoZvTfJs0Bl0GeMF1sStS.NYXkfB7UU7FoZGtOGyZdhLa', '07834230562', 0, '2019-06-22 07:57:39', 'd516b13671a4179d9b7b458a6ebdeb92', '100', '.00'),
(323, 'Dumisani Enoch', 'dumisane.Me2002@gmail.com', '0721877321', 'South Africa', 'USD', NULL, NULL, '$2y$10$5Zl2Cb6Bqc5bTQhoC1RpjuaGdneTbYf82i5w/ABIklcgPxtsQs.0u', 'Monontsha', 1, '2019-06-29 12:35:05', '3a0772443a0739141292a5429b952fe6', '.00', '.00'),
(324, 'Dumisani Enoch', 'dumisane.Me2002@gmail.com', '0721877321', 'South Africa', 'USD', NULL, NULL, '$2y$10$2tBOac2najyvZs36ClanieRK65EQWaEoxvVQQPgV5cE.0YWSeQleW', 'Monontsha', 1, '2019-06-29 12:37:12', 'ebd9629fc3ae5e9f6611e2ee05a31cef', '.00', '.00'),
(325, 'Priyanka Patel', 'capriyankapatel1989@gmail.com', '0527326239', 'United Arab Emirates', 'USD', NULL, NULL, '$2y$10$FdbiGXQM3Lv63DnJRlweCOpXxRU4bEGRhH2/6rGBE7/nS0WVlwKMG', 'Pri.22123', 1, '2019-06-29 13:48:47', '0537fb40a68c18da59a35c2bfe1ca554', '35', '.00'),
(326, 'takiyah_kriwull', 'takiyahkriwul001@gmail.com', '0895396397879', 'Indonesia', 'USD', NULL, NULL, '$2y$10$tAsTCPVFnWZaCyHqZ3dEoOgSNJ0MtSv6A/3pttY3JINah6gvcEnlm', 'Cok1234567890', 1, '2019-06-29 14:33:58', 'ccc0aa1b81bf81e16c676ddb977c5881', '35', '.00'),
(327, 'Hazel', 'traderkiddykyse16@gmail.com', '0673554547', 'South Africa', 'GBP', NULL, NULL, '$2y$10$E.APLh22uAfDcU1xl9rRuezGhqtyxtvzVo.NKfRkIzRML5bF1SIFm', 'Xolanathi16', 1, '2019-06-29 14:59:23', '496e05e1aea0a9c4655800e8a7b9ea28', '7', '.00'),
(328, 'Faris adilah', 'farisadilah@yahoo.com', '+62895609834816', 'Indonesia', 'USD', NULL, NULL, '$2y$10$dz2sutKegKAvu3YLotRYiOh/fLt3guJsO4nrkrAJGxKbFCXe.ZGBy', 'farismega22', 1, '2019-06-29 17:26:05', '28267ab848bcf807b2ed53c3a8f8fc8a', '20', '.00'),
(329, 'Joshua Crawford Hurst', 'wardmega999@gmail.com', '0507927571', 'United Arab Emirates', 'USD', NULL, NULL, '$2y$10$PsuLpc8I0RPtw3./Tgw0oOCk4GOlTHVWbHc6EYybJfED3va1GZz4a', 'msjj2009', 1, '2019-07-01 06:58:41', 'ae0eb3eed39d2bcef4622b2499a05fe6', '35', '.00'),
(330, 'Nicky andre', 'nickyandre2910@gmail.com', '089657203136', 'Indonesia', 'USD', NULL, NULL, '$2y$10$x8TSgn7Y9d.43Y9Ke2M/nOoq8O0Dpv/1BjcGr/8O2kLFjv4VZxSBm', 'NickyAndre2910', 1, '2019-07-02 02:30:39', 'a4a042cf4fd6bfb47701cbc8a1653ada', '.00', '.00'),
(331, 'Enoch', 'dumisane.Me2002@gmail.com', '+27764851472', 'South Africa', 'USD', NULL, NULL, '$2y$10$1qpN5rKxdu02fIA33RNsK.gFX53axKqLL9CzKTkmKyKXqeasijwym', 'Monontsha', 1, '2019-07-02 12:48:36', '1afa34a7f984eeabdbb0a7d494132ee5', '.00', '.00'),
(332, 'Mohamed ramadan', 'bakrm614@gmail.com', '01068957305', 'Egypt', 'USD', NULL, NULL, '$2y$10$E7uif8l6tU6Lqf4BGZ0/kepG8L1opUc2zmNNrgnqdvqipHAoQZYq2', '123321@flos', 1, '2019-07-06 07:57:01', '44c4c17332cace2124a1a836d9fc4b6f', '15', '.00'),
(333, 'Antonio Wayne Goncalves', 'AntonioWayneGoncalves@yahoo.com', '', 'USA', 'USD', NULL, NULL, '$2y$10$ZdzFUeGjly8sbE/WvBMg.erzTE4wQY0oIjPSDriZr0g48RVFWLDBi', 'Lilmike99..', 1, '2019-07-07 16:09:55', '7fe1f8abaad094e0b5cb1b01d712f708', '5,300,000', '.00'),
(334, 'Gregory White', 'gregorywhite450@gmail.com', '+16183100715', 'United States', 'USD', NULL, NULL, '$2y$10$N7NvvGyZOWBiczm8vJoOTubDUq0QZvZ4FEYOrMMwD4QbFetmUUZhq', 'gregiwhite', 1, '2019-07-08 17:29:51', '192fc044e74dffea144f9ac5dc9f3395', '6345700', '.00'),
(335, 'Elison Gawanab', 'Gawanabkenny44@mail.com', '0817768124', 'Namibia', 'GBP', NULL, NULL, '$2y$10$7zfFZk/6KudY3n7W2nKg8O663gfw95kXpfdm1B7oERAiQKdYTF6JW', 'melodykenny2', 1, '2019-07-09 13:03:47', 'ca75910166da03ff9d4655a0338e6b09', '.00', '.00'),
(336, 'MMATLI PATRICK MAKHARI', 'mmatlipatrick@gmail.com', '0735028577', 'South Africa', 'USD', NULL, NULL, '$2y$10$bQPixHoi4hkfnMRCLCI4ReWOlSBT/CvV1t0fw1c03fhavBZm70YOS', 'haketsebe', 1, '2019-07-09 13:56:41', 'bac9162b47c56fc8a4d2a519803d51b3', '.00', '.00'),
(337, 'Patrick Katongole', 'pkatongole9@gmail.com', '0704612911', 'Uganda', 'USD', NULL, NULL, '$2y$10$8Ogr502F6MgksX6ZKPONDOHDQM/ARV2tNtdv.NcuJuFfBvrJC9hE.', '0704612911', 1, '2019-07-09 18:45:21', '9766527f2b5d3e95d4a733fcfb77bd7e', '.00', '.00'),
(338, 'Steven Antoine Walker', 'bankteller87@gmail.com', '475-237-8449', 'United States', 'USD', NULL, NULL, '$2y$10$d1W8zjNtFbNOqniS/KjZNuN9dbZDQ45TrheIhUTH0YMUvxZYW.kCy', 'Bank$hot87', 1, '2019-07-12 03:01:42', '3d2d8ccb37df977cb6d9da15b76c3f3a', '.00', '.00'),
(341, 'Symphani Sanchez', 'symphanisanchez@aim.com', '15165577937', 'United States', 'USD', NULL, NULL, '$2y$10$BcS1crDfGzeo3VQfyQHFt.tP/lccB6Nma4Facz1lqRswFuuHLhrG6', 'ilovehim327', 1, '2019-07-14 20:03:52', '98b297950041a42470269d56260243a1', '1922', '.00'),
(340, 'Ramon J Webb', 'rjwebb240@gmail.com', '7736889545', 'United States', 'USD', NULL, NULL, '$2y$10$uK.FxR45Ysnxc6c98Upra.j3cLwkfmVbwkUpqBSVa6mHp9I/mXZtu', 'Money@7414', 1, '2019-07-12 22:31:04', '621bf66ddb7c962aa0d22ac97d69b793', '7', '.00'),
(342, 'MacDonald Zulu', 'kobuscarter22@gmail.com', '0786833884', 'South Africa', 'USD', NULL, NULL, '$2y$10$tbtEEc3ujoEcLDAKGWzzYeugxwR9mkFdbHqP31UMLv3EmQ8ziqL3q', '221422pq', 1, '2019-07-15 17:54:05', 'e5f6ad6ce374177eef023bf5d0c018b6', '5', '.00'),
(343, 'Moaz sayed', 'moaz32saey@gmail.com', '01124930266', 'Egypt', 'USD', NULL, NULL, '$2y$10$J.wY9UnKnlTgCMykjv8VNuazbBcwWZ5yBH03pOy2XaYgC01k6DiE.', 'moaz102030', 1, '2019-07-18 17:47:20', 'da4fb5c6e93e74d3df8527599fa62642', '.00', '.00'),
(344, 'Reena Ibrahim', 'reenaibrahim1924@hotmail.com', '98149912', 'Oman', 'USD', NULL, NULL, '$2y$10$kvRd0357O4.AIzrsw9Z5JO67DzInOAUUhPocq.P49bjfb3z1F5dvi', 'reena', 1, '2019-07-20 11:04:35', '17d63b1625c816c22647a73e1482372b', '1300000', '.00'),
(345, 'Kimmy Sekoala', 'revelationsekoala@gmail.com', '0626233524', 'South Africa', 'USD', NULL, NULL, '$2y$10$sKo3SP0jn9WwjFNExrvvWelZPYdZAmr0874D97.HUWh1efkNGssvy', 'koki22061', 1, '2019-07-20 15:51:53', '42a0e188f5033bc65bf8d78622277c4e', '.00', '.00'),
(346, 'Thabo Mtetwa', 'bmglyfstyle@gmail.com', '0637712252', 'South Africa', 'USD', NULL, NULL, '$2y$10$jOTBdJf9cuVc7XhG4fk0MujprYWcek39SFlNOapwQNAMkldC7rQTG', 'theofficialbmg', 1, '2019-07-20 23:11:29', 'fe131d7f5a6b38b23cc967316c13dae2', '5', '.00'),
(347, 'Sbesahraoui', 'besahraouisaid@icloud.com', '0557777573', 'Algeria', 'USD', NULL, NULL, '$2y$10$iOpVo8L1aXVTZkj9S27vBu.kD2UMCtZu0crg/A48Hci5iVkXg6606', 'Ilovealah77', 1, '2019-07-21 13:36:46', '3435c378bb76d4357324dd7e69f3cd18', '.00', '.00'),
(348, 'Vicky Saini', 'Vickysaini143@gmail.com', '8130223313', 'India', 'USD', NULL, NULL, '$2y$10$WfBS3xvEFkXsNaDucoGVDOz4Hm7IW8jgKG1SYLaoUw8yCtJhJs70u', 'Neetu143', 1, '2019-07-22 12:03:48', '051e4e127b92f5d98d3c79b195f2b291', '.00', '.00'),
(349, 'Mia', 'Mia102673@gmail.com', '4435628464', 'United States', 'USD', NULL, NULL, '$2y$10$7EuqwnsyzjsN01wBK1qIv.73qKLha3LrDPQC.YssRwiFEYd/E0qvy', 'Vhecpqt4', 1, '2019-07-22 17:23:16', '502e4a16930e414107ee22b6198c578f', '.00', '.00'),
(350, 'Bibiana Echeverry Raigoza', 'bcf.atleta@gmail.com', '+50684765933', 'Costa Rica', 'USD', NULL, NULL, '$2y$10$afDCLwwV0.syp.e./3lQTen2TgQtFekXojbClloEu6hlGMO4Q0T16', 'Venzat20095', 1, '2019-07-22 18:28:27', '692f93be8c7a41525c0baf2076aecfb4', '31000', '.00'),
(351, 'Mohammad alhumood', 'm_alhumood@hotmail.com', '55770082', 'Kuwait', 'USD', NULL, NULL, '$2y$10$Yv.Fp0CG6LQPONc6xCLL/O564n2.TQ13zvVEt.WbzROtkZj5i3bEm', 'modena123', 1, '2019-07-23 16:07:44', '16c222aa19898e5058938167c8ab6c57', '506487', '.00'),
(352, 'Melvin Birtantie', 'karanmls@outlook.com', '0031651341456', 'Netherlands', 'EUR', NULL, NULL, '$2y$10$HzcYZSQRIqV0u0UHZhvum.0lGMN0Q1nrdM/UvGDtq9EklaM5mvOja', 'axamsli27', 1, '2019-07-24 19:06:33', '5dd9db5e033da9c6fb5ba83c7a7ebea9', '.00', '.00'),
(353, 'Saad Nasir', 'nasirsaad569@gmail.com', '4049880559', 'United States', 'USD', NULL, NULL, '$2y$10$4IRdwMX4pPqkuLEjed9Ry.E.gHRr95wLw8l08Kcm.aoiQ.kmxO9NC', 'forex187', 1, '2019-07-24 22:53:50', '36660e59856b4de58a219bcf4e27eba3', '.00', '.00'),
(354, 'Tanelious Walton', 'tanelious.walton@yahoo.com', '8134207329', 'United States', 'USD', NULL, NULL, '$2y$10$b2ZnXrl6jvE/Tiuzsq2JauIVOX9vjg2Noxv/sVMWdbNlJ4rnBPN3K', 'October894*', 1, '2019-07-29 01:19:01', '1068c6e4c8051cfd4e9ea8072e3189e2', '.00', '.00'),
(355, 'LeÃ¯la TurgnÃ©', 'leila.turgne.17@hotmail.com', '0617051670', 'France', 'EUR', NULL, NULL, '$2y$10$86RQTtfmmf3dIE/Skd56ZelSuHIzP5W1YwZn0iz.3IB4v3aT4EOH.', 'milanewilem2012', 1, '2019-08-01 13:37:08', 'e97ee2054defb209c35fe4dc94599061', '.00', '.00'),
(358, 'Bharat Singh', 'rajassbkohli2020@gmail.com', '9460321421', 'India', 'USD', NULL, NULL, '$2y$10$8kOa7CUwAnBzCVQGCKy7JOsDgvFuVJVMEem8e0p1Z9GaCgUFDiLby', 'Bharat2.#', 1, '2019-08-09 07:23:00', '3a835d3215755c435ef4fe9965a3f2a0', '.00', '.00'),
(357, 'Montaser montaser mosbah abdou', 'montasermosbah2222@yahoo.com', '01277610842', 'Egypt', 'USD', NULL, NULL, '$2y$10$jMB/79h74QT.ZXK.85Ua2O096RtSJOwP.sNzUFyHQ34BrHKF2LGWG', 'montaser123', 1, '2019-08-04 17:44:01', 'c5ab0bc60ac7929182aadd08703f1ec6', '.00', '.00'),
(365, 'mmmmmmmmmmmm', 'mm@jjjj.bom', 'kkkkk', 'Antarctica', 'EUR', NULL, NULL, '$2y$10$5e/I/WBLsXHCiffVX1jk9O8Km1RYcrtMaPwQ5UVBzD/nrakqFg1my', 'llllllllll', 1, '2019-09-17 11:07:01', '577ef1154f3240ad5b9b413aa7346a1e', '.00', '.00'),
(364, 'SSSSSSSSSSSS', 'SSSSS@amdi.com', 'aaaaaaaaaaaa', 'Austria', 'EUR', NULL, NULL, '$2y$10$Z12J9J1Q3PPpDmGT.hJuJ.Kp8qxnfHH6VZ7DKy7aVzcXXQfJZUeUO', 'aaaaaaaaaaaa', 1, '2019-09-17 11:05:58', '39059724f73a9969845dfe4146c5660e', '.00', '.00');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw`
--

DROP TABLE IF EXISTS `withdraw`;
CREATE TABLE IF NOT EXISTS `withdraw` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `amount` int(11) NOT NULL,
  `payment` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `withdraw`
--

INSERT INTO `withdraw` (`id`, `name`, `amount`, `payment`, `date`, `active`) VALUES
(90, 'Elijah', 20, 'bitcoins', '2019-06-15 09:18:14', 0),
(89, 'joy cole', 1000, 'Bank wire transfer', '2019-06-10 13:54:23', 0),
(88, 'joy cole', 900, 'Bank wire transfer', '2019-06-10 13:35:35', 0),
(87, 'joy cole', 900, 'Bank wire transfer', '2019-06-10 13:26:34', 0),
(86, 'Ighomuaye Cordelia', 900, 'Bank wire transfer', '2019-06-10 13:19:27', 0),
(85, 'Ighomuaye Cordelia', 900, 'Bank wire transfer', '2019-06-10 11:09:25', 0),
(84, 'Ighomuaye Cordelia', 900, 'Bank wire transfer', '2019-06-10 11:09:16', 0),
(91, 'James Clifford Clarke', 1000000, 'Bank wire transfer', '2019-06-25 07:01:36', 1),
(92, 'James Clifford Clarke', 1000000, 'Bank wire transfer', '2019-06-25 07:07:27', 0),
(93, 'Andreas Martinka', 120, 'Bank wire transfer', '2019-06-29 07:29:17', 0),
(94, 'Ntando', 20, 'Bank wire transfer', '2019-06-30 02:57:26', 0),
(95, 'Portia', 8500, 'Bank wire transfer', '2019-07-02 13:29:24', 0),
(96, 'Portia', 8500, 'Bank wire transfer', '2019-07-02 13:32:45', 0),
(97, 'Ntando', 35, 'bitcoins', '2019-07-06 15:50:11', 0),
(98, 'Andreas Martinka', 15005, 'bitcoins', '2019-07-20 15:31:30', 0),
(99, 'Bibiana Echeverry Raigoza', 100, 'Bank wire transfer', '2019-07-24 22:51:32', 0),
(100, 'Bibiana Echeverry Raigoza', 100, 'Bank wire transfer', '2019-07-24 23:01:41', 0),
(101, 'Andreas Martinka', 15005, 'bitcoins', '2019-07-28 08:52:29', 0),
(102, 'Gregory White', 500000, 'bitcoins', '2019-07-29 22:34:17', 0),
(103, 'Gregory White', 100000, 'bitcoins', '2019-07-29 22:34:32', 0),
(104, 'Gregory White', 100000, 'bitcoins', '2019-07-29 22:35:22', 0),
(105, 'Gregory White', 20000, 'Bank wire transfer', '2019-07-29 22:35:37', 0),
(106, 'Portia', 8500, 'Bank wire transfer', '2019-08-02 15:29:58', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
