<?php

//start session
session_start();

//Check if Userhas been signed in
if(!isset($_SESSION['capitalAdmin'])){
	header("location:index.php");
}
include('includes/header.php');


include('includes/connection.php');




if(isset($_POST['fund'])){

	$result = $_POST['result'];
	$profit = $_POST['profit'];
	$id = $_POST['id'];

	$query = "UPDATE trade 
	SET result = '$result',profit='$profit'
	WHERE id = '$id'

	";

	$result = mysqli_query($conn,$query);
}




if(isset($_POST['update_date'])){

	$date = $_POST['date'];
	$expiry = $_POST['expiry'];
	$id = $_POST['id'];

	$query = "UPDATE trade 
	SET expiry = '$expiry',date='$date',active = 1
	WHERE id = '$id'

	";

	$result = mysqli_query($conn,$query);
}





?>

<!-- Main Container -->
<main id="main-container">
	<!-- Page Content -->
	<div class="content">


		<!-- Block Tabs Content Animation -->
		<h2 class="content-heading">Requests</h2>
		<div class="row">
			<div class="col-lg-12">
				<!-- Block Tabs Animated Fade -->
				<div class="block">
					<ul class="nav nav-tabs nav-tabs-block" data-toggle="tabs" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" href="#btabs-animated-fade-trade">Active Trade</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#btabs-animated-fade-tradehistory">Trade History</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#btabs-animated-fade-withdrawhistory">Withdraw History</a>
						</li>
						
					</ul>
					<div class="block-content tab-content overflow-hidden">
						
						<div class="tab-pane fade show active" id="btabs-animated-fade-trade" role="tabpanel">
							<!-- Full Table -->
							<div class="block">
								
								<div class="block-content">
									
									<div class="table-responsive">
										<table class="table table-striped table-vcenter">
											<thead>
												<tr>
													<th class="text-center" style="width: 100px;"></th>
													<th>Name</th>
													<th style="width: 15%;">Trade Type</th>
													<th style="width: 15%;">Amount</th>
													<th>Asset</th>
													<th>Result</th>
													<th>Profit</th>
													<th>Update</th>
													<th style="width: 10%;">Delete</th>
													<th>Edit Date</th>
												</tr>
											</thead>
											<tbody>
												<?php
												$i=1;

												$query = "SELECT * FROM `trade` ORDER BY id DESC";

												$result = mysqli_query($conn,$query);

												if(mysqli_num_rows($result) > 0 ){

													while($row =mysqli_fetch_assoc($result)){

														$s_time = $row['date'];

														$id = $row['id'];
														$name = $row['name'];

														?>

														<tr>
															<td><?php echo $i++;?></td>
															<td><?php echo $row['name'];?></td>
															<td><?php echo $row['type'];?></td>
															<td><?php echo $row['credit'];?></td>
															<td><?php echo $row['asset'];?></td>
															<td><?php echo $row['result'];?></td>
															<td><?php echo $row['profit'];?></td>



															<td>
																<form action="" method="post">
																	<select class="form-control"  name="result" >
																		<option disabled="" selected="">Select</option>
																		<option value="Won">Won</option>
																		<option value="Loss">Loss</option>
																	</select>
																	<input class="form-control"  type="text" name="profit"  placeholder="profit" required/>
																	<input class="form-control" type="hidden" name="id" value="<?php echo $row['id']; ?>" >
																	<input class="btn btn-success"  type="submit" name="fund" value="Update" class="">

																</form>
															</td>
															<td><?php	echo'<a href="tradedelete.php?id=' . $row["id"] . '" class="btn btn-danger" onclick="alert(\'Are you sure you want to delete this user?\')" role="button"><i class="fa fa-close"></i></a>&nbsp;';?></td>
													        <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter<?=$id?>">
  Edit Date
</button></td>
														</tr>
														<?php }}?>

													</tbody>
												</table>
											</div>
										</div>
									</div>
									<!-- END Full Table -->


								</div>
								
								
								
						<div class="tab-pane fade" id="btabs-animated-fade-tradehistory" role="tabpanel">
							<!-- Full Table -->
							<div class="block">
								
								<div class="block-content">
									
									<div class="table-responsive">
										<table class="table table-striped table-vcenter">
											<thead>
												<tr>
													<th class="text-center" style="width: 100px;"></th>
													<th>Name</th>
													<th style="width: 15%;">Trade Type</th>
													<th style="width: 15%;">Amount</th>
													<th>Asset</th>
													<th>Result</th>
													<th>Profit</th>
												
													<th style="width: 10%;">Delete</th>
													<th>Edit Date</th>
												</tr>
											</thead>
											<tbody>
												<?php
												$i=1;

												$query = "SELECT * FROM `trade` where active = 1 ORDER BY id DESC";

												$result = mysqli_query($conn,$query);

												if(mysqli_num_rows($result) > 0 ){

													while($row =mysqli_fetch_assoc($result)){

														$s_time = $row['date'];

														$id = $row['id'];
														$name = $row['name'];

														?>

														<tr>
															<td><?php echo $i++;?></td>
															<td><?php echo $row['name'];?></td>
															<td><?php echo $row['type'];?></td>
															<td><?php echo $row['credit'];?></td>
															<td><?php echo $row['asset'];?></td>
															<td><?php echo $row['result'];?></td>
															<td><?php echo $row['profit'];?></td>



															<!--<td>-->
															<!--	<form action="" method="post">-->
															<!--		<select class="form-control"  name="result" >-->
															<!--			<option disabled="" selected="">Select</option>-->
															<!--			<option value="Won">Won</option>-->
															<!--			<option value="Loss">Loss</option>-->
															<!--		</select>-->
															<!--		<input class="form-control"  type="text" name="profit"  placeholder="profit" required/>-->
															<!--		<input class="form-control" type="hidden" name="id" value="<?php echo $row['id']; ?>" >-->
															<!--		<input class="btn btn-success"  type="submit" name="fund" value="Update" class="">-->

															<!--	</form>-->
															<!--</td>-->
															<td><?php	echo'<a href="tradedelete.php?id=' . $row["id"] . '" class="btn btn-danger" onclick="alert(\'Are you sure you want to delete this user?\')" role="button"><i class="fa fa-close"></i></a>&nbsp;';?></td>
													        <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter<?=$id?>">
  Edit Date
</button></td>
														</tr>
														<?php }}?>

													</tbody>
												</table>
											</div>
										</div>
									</div>
									<!-- END Full Table -->


								</div>

								<div class="tab-pane fade" id="btabs-animated-fade-withdrawhistory" role="tabpanel">
									<!-- Full Table -->
									<div class="block">

										<div class="block-content">

											<div class="table-responsive">
												<table id="datatable" class="table table-bordered">
													<thead>

														<tr>
															<th class="text-center" style="width: 100px;"></th>
															<th>Name</th>
															<th >Amount</th>
															<th >Payment</th>
															<th>Date</th>
															<th class="text-center" style="width: 100px;">Actions</th>
														</tr>
													</thead>
													<tbody>
														<?php
														$i=1;

														$query = "SELECT * FROM `withdraw` where active = 1  ORDER BY id DESC";

														$result = mysqli_query($conn,$query);

														if(mysqli_num_rows($result) > 0 ){

															while($row =mysqli_fetch_assoc($result)){

																$s_time = $row['date'];

																$id = $row['id'];
																$name = $row['name'];

																?>
																<tr>
																	<td><?php echo $i++;?></td>
																	<td><?php echo $row['name'];?></td>
																	<td><?php echo $row['amount'];?></td>
																	<td><span class="badge badge-info"><?php echo $row['payment'];?></span></td>
																	<td><?php echo $row['date'];?></td>
																	<td class="text-center" >
																		<?php	echo'<a href="withdrawdelete.php?id=' . $row["id"] . '" onclick="alert(\'Are you sure you want to delete this user?\')" role="button" class="btn btn-danger"><i class="fa fa-close"></i></a>';?>
																	</td>
																</tr>
																<?php }}?>

															</tbody>
														</table>
													</div>
												</div>
											</div>
											<!-- END Full Table -->






										</div>
									</div>
									<!-- END Block Tabs Animated Fade -->


								</div>

							</div>
							<!-- END Block Tabs Content Animation -->
						</div>
						<!-- END Page Content -->
					</main>
					<!-- END Main Container -->
					
					
					<?php
											

												$query = "SELECT * FROM `trade` where active = 1 ORDER BY id DESC";

												$result = mysqli_query($conn,$query);

												if(mysqli_num_rows($result) > 0 ){

													while($row =mysqli_fetch_assoc($result)){

													

														$id = $row['id'];
					
					?>
					<div class="modal fade" id="exampleModalCenter<?=$id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalCenterTitle">Change Trade Date For <?=$row['name']?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                             <form method="post">
                                  <div class="row">
                                    <div class="col">
                                        <label>Start Date</label>
                                      <input type="date" name="date" class="form-control"  value="<?php echo strftime('%Y-%m-%d',strtotime($row['date'])); ?>">
                                    </div>
                                    <div class="col">
                                        <label>Stop Date</label>
                                      <input type="date" name="expiry" class="form-control" value="<?php echo strftime('%Y-%m-%d',strtotime($row['expiry'])); ?>">
                                      
                                       <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    </div>
                                  </div>
                            <div class="modal-footer" style="align:center">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button name="update_date" class="btn btn-primary">Save changes</button>
                              </div>
                                </form>
                              </div>
                             
                            </div>
                          </div>
                        </div>
					
					<?php }}?>
					
					


					<?php 
					include('includes/footer.php');

					?>