<?php 	
//Declaring connection variables

$servername = "localhost";
$username = "root";
$password = "";
$db = "bank";


$conn = new mysqli($servername,$username,$password,$db);


if($conn->connect_error){
	die("Error in Connection".$conn->connect_error);
}else{
	
}


?>