<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


//Load composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer();                              // Passing `true` enables exceptions
try {
    $mail->SMTPDebug = 0;                                		 // Enable verbose debug output
    $mail->isSMTP();                                     	    // Set mailer to use SMTP
    $mail->Host = 'localhost';  						   // Specify main and backup SMTP servers
    $mail->Port = 25;   
    $mail->SMTPAuth = true;                               	  // Enable SMTP authentication
    $mail->Username = 'contact@capitalglobalmarket.com';                	 // SMTP username
    $mail->Password = '@Compaq2014';                         // SMTP password

    
    //Recipients
    $mail->setFrom('contact@capitalglobalmarket.com', 'Capital Global Market');
    $mail->addAddress('contact@capitalglobalmarket.com');     // Add a recipient
    
    //Content
    //$mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Loan | Notification';
    $mail->Body    = '
 
        
        A User has just placed a Loan Request,
        These are following credentials submitted:
         
        ------------------------
        Name : '.$name.'
        Email: '.$_SESSION['capitalEmail'].'
        Request: '.$payment.' 
        Amount: '.$amount.'
        ------------------------
        
         Please click this link or copy and paste on a new tab to view new request:
         https://capitalglobalmarket.com/auth_admin
         ';
   
    $mail->send();
   // echo 'Message has been sent';
} catch (Exception $e) {
	echo 'Message could not be sent.';
	echo 'Mailer Error: ' . $mail->ErrorInfo;
}

?>