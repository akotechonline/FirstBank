<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


//Load composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer();                              // Passing `true` enables exceptions
try {
    //Server settings
       $mail->SMTPDebug = 0;                                         // Enable verbose debug output
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host = 'localhost';                          // Specify main and backup SMTP servers
    $mail->Port = 25;   
    $mail->SMTPAuth = true;                                   // Enable SMTP authentication
    $mail->Username = 'contact@capitalglobalmarket.com';                    // SMTP username
    $mail->Password = '@Compaq2014';                           // SMTP password
                         // SMTP password

    
    //Recipients
    $mail->setFrom('contact@capitalglobalmarket.com','E-mail Verification');
    $mail->addAddress($email,$name);     // Add a recipient
    
    //Content
    //$mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Signup | Verification';
    $mail->Body    = '
    
    Thanks for signing up!
        Your account has been created,Please activate by clicking the link. Below are your login details
         
        ------------------------
        Username: '.$_POST['email'].'
        Password: '.$_POST['password'].'
        ------------------------
         
        Please click this link or copy and paste on a new tab to activate your account:
        https://capitalglobalmarket.com/app/verify.php?email='.$email.'&hash='.$hash.'';
    
    $mail->send();
    //echo 'Message has been sent';
} catch (Exception $e) {
	echo 'Message could not be sent.';
	echo 'Mailer Error: ' . $mail->ErrorInfo;
}

?>