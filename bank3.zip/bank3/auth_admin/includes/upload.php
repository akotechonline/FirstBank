
<?php  
$file = $_FILES['file'];
$fileName = $_FILES['file']['name'];
$fileTmpName = $_FILES['file']['tmp_name'];
$fileSize = $_FILES['file']['size'];
$fileError = $_FILES['file']['error'];
$fileType = $_FILES['file']['type'];

$fileExt = explode('.', $fileName);
$fileActualExt = strtolower(end($fileExt));

$allowed = array('jpg','jpeg','png','gif','pdf');

if (in_array($fileActualExt, $allowed)){

    if($fileError == 0){
        if($fileSize < 8388608){
            $fileNameNew = $fileName;
            $fileDestination = $target.$fileNameNew;
            move_uploaded_file($fileTmpName, $fileDestination);

            $msg =  "<div class='alert alert-success text-center'>Document is uploaded  click this link to <strong><a href='index.php'>Login</a></strong><a class='close' data-dismiss='alert'>&times</a></div>";
        }else{
            $msg = "<div class='alert alert-danger text-center'>File is too large <a class='close' data-dismiss='alert'>&times</a></div>";
        }
    }else{
        $msg =  "<div class='alert alert-danger text-center'>Error Uploading files uploading files <a class='close' data-dismiss='alert'>&times</a></div>";
    }
}else{
    $msg =  "<div class='alert alert-danger text-center'>You cannot upload files of this type <a class='close' data-dismiss='alert'>&times</a></div>";
}


?>