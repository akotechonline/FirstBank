<?php

//start session
session_start();

//Check if Userhas been signed in
if(!isset($_SESSION['capitalAdmin'])){
	header("location:index.php");
}
include('includes/header.php');


include('includes/connection.php');



if(isset($_POST['fund'])){

	$credit = $_POST['credit'];
	$id = $_POST['id'];

	$query = "UPDATE users 
	SET credit = '$credit'
	WHERE id = '$id'

	";

	$result = mysqli_query($conn,$query);

}





?>
<!-- Main Container -->
<main id="main-container">
	<!-- Page Content -->
	<div class="content">


		<!-- Full Table -->
		<div class="block">
			<div class="block-header block-header-default">
				<h3 class="block-title">Request:</h3>
			</div>
			<div class="block-content">

				<div class="table-responsive">
					<table class="table table-striped table-vcenter">
						<thead>
							<tr>
								<th class="text-center" style="width: 100px;"></th>
								<th>Name</th>
								<th>Balance</th>
								<th>Fund</th>
							</tr>
						</thead>
						<tbody>
							<?php

							$i = 1;
							$query = "SELECT * FROM `users` ORDER BY id DESC";

							$result = mysqli_query($conn,$query);

							if(mysqli_num_rows($result) > 0 ){

								while($row =mysqli_fetch_assoc($result)){



									$id = $row['id'];
									$name = $row['name'];
									?>
									<tr>
										<td >
											<?php echo $row['id'];?>
										</td>
										<td ><?php echo $row['name'];?></td>
										<td><i class="badge badge-info badge fa fa-dollar">&nbsp;&nbsp;

											<?php
											$sql = "select sum(credit) from users where id = '$id'";
											$q = mysqli_query($conn,$sql);
											$rowq = mysqli_fetch_array($q);

											echo $rowq[0];

											?></i></td>
											<td>

												<form  method="post">
													<input type="text" name="credit" width="20px" required 
													/>
													<input type="hidden" name="id" value="<?php echo $row['id']; ?>" >
													<input type="submit" name="fund" value="Update" class="btn btn-success">
												</form>
											</td>

										</td>

									</tr>
									<?php }}?>


								</tbody>
							</table>
						</div>
					</div>
				</div>
				<!-- END Full Table -->
			</div>
			<!-- END Page Content -->
		</main>
		<!-- END Main Container -->

		<?php 
		include('includes/footer.php');

		?>