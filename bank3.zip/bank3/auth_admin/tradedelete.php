<?php
include('includes/connection.php');

/*
Author: Javed Ur Rehman
Website: http://www.allphptricks.com/
*/


$id = $_GET['id'];
if(isset($id)) {
	$query = "SELECT * FROM trade";
	$result = mysqli_query($conn, $query);
	if(mysqli_num_rows($result) >= 1) {
		$query = "DELETE FROM trade WHERE id=$id";
		mysqli_query($conn, $query);
		header("location:history.php");
	} else {
		echo "Cannot delete";
		header("location:history.php");
	}
}
else{
	header("location:history.php");
}
?>