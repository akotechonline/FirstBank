<?php
include('includes/connection.php');

/*
Author: Javed Ur Rehman
Website: http://www.allphptricks.com/
*/


$id = $_GET['id'];
if(isset($id)) {
	$query = "SELECT * FROM users";
	$result = mysqli_query($conn, $query);
	if(mysqli_num_rows($result) >= 1) {
		$query = "DELETE FROM users WHERE id=$id";
		mysqli_query($conn, $query);
		header("location:users.php");
	} else {
		echo "Cannot delete";
		header("location:users.php");
	}
}
else{
	header("location:users.php");
}
?>