<?php

//start session
session_start();

//Check if Userhas been signed in
if(!isset($_SESSION['capitalAdmin'])){
	header("location:index.php");
}
include('includes/header.php');


include('includes/connection.php');




$me = $_GET['id'];




?>

<!-- Main Container -->
<main id="main-container">
	<!-- Page Content -->
	<div class="content">
		

		<!-- Full Table -->
		<div class="block">
			<div class="block-header block-header-default">
				<h3 class="block-title">All Users</h3>
			</div>
			<div class="block-content">

				<div class="table-responsive">
					<table class="table table-striped table-vcenter">
						<thead>
							<tr>
								<th>*</th>
								<th>Name</th>
								<th>Email</th>
								<th>Phone</th>
								<th>Front Cover</th>
								<th>Back cover</th>
							
								
							</tr>
						</thead>
						<tbody>
							<?php

							$i = 1;
							$query = "SELECT * FROM `users` where id = '$me' ORDER BY id DESC";

							$result = mysqli_query($conn,$query);

							if(mysqli_num_rows($result) > 0 ){

								while($row =mysqli_fetch_assoc($result)){

									$s_time = $row['signup_date'];
									$doc ='../../uploads/';$doc .= $row['path'];
                                    $doc2 ='../../uploads/';$doc2 .= $row['path2'];
									?>
									<tr>
										<td >
											<?php	echo'<a href="delete.php?id=' . $row["id"] . '" onclick="alert(\'Are you sure you want to delete this user?\')" role="button" class="btn btn-danger"><i class="fa fa-close"></i></a>';?>
										</td>
										<td><?php echo $row['name'];?></td>
										<td><?php echo $row['email'];?></td>
										<td>
											<?php echo $row['telephone'];?>
										</td>
										<td >
											<?php echo  "<img src='".$doc."' class = 'picture-src' alt='Profile Pic'>";?>
									
									</td>
								<td >
											<?php echo  "<img src='".$doc2."' class = 'picture-src' alt='Profile Pic'>";?>
									
									</td>

								</tr>

								<?php }}?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- END Full Table -->
		</div>
		<!-- END Page Content -->
	</main>
	<!-- END Main Container -->



	<?php 
	include('includes/footer.php');

	?>