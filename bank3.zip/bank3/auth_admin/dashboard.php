

<?php

//start session
session_start();

//Check if Userhas been signed in
if(!isset($_SESSION['capitalAdmin'])){
	header("location:index.php");
}
include('includes/header.php');


include('includes/connection.php');






if(isset($_POST['active'])){


	$id = $_POST['id'];


	$query = "UPDATE withdraw 
	SET active = 1
	WHERE id = '$id'

	";

	$result = mysqli_query($conn,$query);
}


if(isset($_POST['fund'])){

	$credit = $_POST['credit'];
	$id = $_POST['id'];

	$query = "UPDATE trade 
	SET credit = '$credit',active = 1
	WHERE id = '$id'

	";

	$result = mysqli_query($conn,$query);
}






?>

<!-- Main Container -->
<main id="main-container">
	<!-- Page Content -->
	<div class="content">


		<!-- Block Tabs Content Animation -->
		<h2 class="content-heading">Requests</h2>
		<div class="row">
			<div class="col-lg-12">
				<!-- Block Tabs Animated Fade -->
				<div class="block">
					<ul class="nav nav-tabs nav-tabs-block" data-toggle="tabs" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" href="#btabs-animated-fade-trade">Trade</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#btabs-animated-fade-deposit">Deposit</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#btabs-animated-fade-pending">Pending Withdraw</a>
						</li>
						
					</ul>
					<div class="block-content tab-content overflow-hidden">
						
						<div class="tab-pane fade show active" id="btabs-animated-fade-trade" role="tabpanel">
							<!-- Dynamic Table Full -->
							<div class="block">

								<div class="block-content block-content-full">
									<!-- DataTables init on table by adding .js-dataTable-full class, functionality initialized in js/pages/be_tables_datatables.js -->
									<table class="table table-bordered table-striped table-vcenter js-dataTable-full">
										<thead>
											<tr>
												<th class="text-center"></th>
												<th>Name</th>
												<th class="d-none d-sm-table-cell">Trade Type</th>
												<th class="d-none d-sm-table-cell">Start Date</th>
												<th class="d-none d-sm-table-cell">End Date</th>
												<th class="d-none d-sm-table-cell">Amount</th>
												<th class="d-none d-sm-table-cell">Actions</th>
												<th class="d-none d-sm-table-cell">Fund</th>
												
											</tr>
										</thead>
										<tbody>
											<?php

											$i = 1;
											$query = "SELECT * FROM `trade` where active = 0 ORDER BY id DESC";

											$result = mysqli_query($conn,$query);

											if(mysqli_num_rows($result) > 0 ){

												while($row =mysqli_fetch_assoc($result)){

													$s_time = $row['date'];


													?>
													<tr>
														<td><?php echo $i++;?></td>
														<td><?php echo $row['name'];?></td>
														<td><?php echo $row['type'];?></td>
														<td><?php echo date(" dS  F Y " ,strtotime($s_time));?></td>
														<td><?php echo $row['expiry'];?></td>
														<td><?php echo $row['amount'];?></td>
														<td><?php echo $row['action'];?></td>
														<td>
															<form action="" method="post">
																<input type="text" name="credit" width="20px" required 
																/>
																<input type="hidden" name="id" value="<?php echo $row['id']; ?>" >
																<input type="submit" name="fund" value="Fund" class="btn btn-success">
																
															</form>
														</td>

													</tr>
													<?php }}?>

												</tbody>
											</table>
										</div>
									</div>
									<!-- END Dynamic Table Full -->

								</div>

								<div class="tab-pane fade" id="btabs-animated-fade-pending" role="tabpanel">
									<!-- Dynamic Table Full -->
									<div class="block">

										<div class="block-content block-content-full">
											<!-- DataTables init on table by adding .js-dataTable-full class, functionality initialized in js/pages/be_tables_datatables.js -->
											<table class="table table-bordered table-striped table-vcenter js-dataTable-full">
												<thead>
													<tr>
														<th class="text-center"></th>
														<th>Name</th>
														<th class="d-none d-sm-table-cell">Amount</th>
														<th class="d-none d-sm-table-cell" >Payment</th>
														<th class="text-center" >Date</th>
														<th class="d-none d-sm-table-cell" >Action</th>

													</tr>
												</thead>
												<tbody>
													<?php

													$i = 1;
													$query = "SELECT * FROM `withdraw` where active = 0 and payment !='loan'";

													$result =mysqli_query($conn,$query);

													if(mysqli_num_rows($result) > 0 ){

														while($row =mysqli_fetch_assoc($result)){



															?>
															<tr>
																<td><?php echo $i++;?></td>
																<td><?php echo $row['name'];?></td>
																<td><?php echo $row['amount'];?></td>
																<td><?php echo $row['payment'];?></td>
																<td><?php echo $row['date'];?></td>
																<td>

																	<form action="" method="post">

																		<input type="hidden" name="id" value="<?php echo $row['id']; ?>" >
																		<input type="submit" name="active" value="Accept" class="btn btn-success">

																	</form>
																</td>
															</tr>
															<?php }}?>
														</tbody>
													</table>
												</div>
											</div>
											<!-- END Dynamic Table Full -->
										</div>

										<div class="tab-pane fade" id="btabs-animated-fade-deposit" role="tabpanel">
											<!-- Dynamic Table Full -->
											<div class="block">

												<div class="block-content block-content-full">
													<!-- DataTables init on table by adding .js-dataTable-full class, functionality initialized in js/pages/be_tables_datatables.js -->
													<table class="table table-bordered table-striped table-vcenter js-dataTable-full">
														<thead>
															<tr>
																<th class="text-center"></th>
																<th>Name</th>
																<th class="d-none d-sm-table-cell">Amount</th>
																<th class="d-none d-sm-table-cell" >Date</th>
																<th class="text-center">Payment</th>
															</tr>
														</thead>
														<tbody>
															<?php

															$i = 1;
															$query = "SELECT * FROM `deposit`";

															$result =mysqli_query($conn,$query);

															if(mysqli_num_rows($result) > 0 ){

																while($row =mysqli_fetch_assoc($result)){

																	$w_time = $row['date'];

																	?>
																	<tr>
																		<td><?php echo $i++;?></td>
																		<td><?php echo $row['name'];?></td>
																		<td><?php echo $row['amount'];?></td>
																		
																		<td><?php echo date(" dS  F Y " ,strtotime($w_time));?></td>
																		<td class="text-center">
																			<span class="badge badge-info"><?php echo $row['payment'];?></span>
																		</td>
																	</tr>
																	<?php }}?>
																</tbody>
															</table>
														</div>
													</div>
													<!-- END Dynamic Table Full -->
												</div>



											</div>
										</div>
										<!-- END Block Tabs Animated Fade -->


									</div>

								</div>
								<!-- END Block Tabs Content Animation -->
							</div>
							<!-- END Page Content -->
						</main>
						<!-- END Main Container -->


						<?php 
						include('includes/footer.php');

						?>