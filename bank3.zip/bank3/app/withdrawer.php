<?php

//start session
session_start();

//Check if Userhas been signed in
if(!isset($_SESSION['capitalUser'])){
  header("location:../page-login.php");
}
include('../includes/header.php');


include('../includes/connection.php');

?>


 <div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">PROVIDE TAX CODE</h4>
                  <p class="card-description">
                    Before you can have access to this action please provide your TAX CODE
                  </p>
                  <form class="forms-sample">
                    <div class="form-group">
                      <label for="exampleInputName1">TAX CODE</label>
                      <input type="text" class="form-control" id="exampleInputName1" placeholder="Enter Tax Code">
                    </div>
                   
                   <script type="text/javascript">
                     function myFunction() {
                      alert("Please enter a valid TAX CODE or Reach us through the below contacts")
                     }
                   </script>
                    <button type="submit" class="btn btn-primary mr-2" onclick="myFunction()">Submit</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
            
<h4>CONTACT THE BELOW INFO TO GET YOUR TAX CODE</h4>
<div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                
                  
                  <div class="row">
                    <div class="col-md-6">
                      <address>
                        <p class="font-weight-bold">TAX Office</p>
                        <p>
                          Reparticao de Franancas de Alterdo Noble
                        </p>
                        
                      </address>
                      
                        <p class="font-weight-bold">Address: </p>
                        <p>
                          7440-014 Alter do Noble, Portugal.
                        </p>
                        
                      </address>
                    </div>
                    <div class="col-md-6">
                      <address class="text-primary">
                        <p class="font-weight-bold">
                          Email:
                        </p>
                        <p>
                         support@novobankinc.com
                        </p>

                        <p class="font-weight-bold">
                          E-mail
                        </p>
                        <p class="mb-2">
                          reparticaodefindochao@collector.org
                        </p>
                        
                        <p class="font-weight-bold">
                          Tel:
                        </p>

                        <p>
                          +351245602222
                        </p>
                      </address>
                    </div>
                  </div>
                </div>


