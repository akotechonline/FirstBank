<?php
include('../includes/connection.php');
$msg=$fileNameNew="";


//Email Verification
if(isset($_GET['email']) && !empty($_GET['email']) AND isset($_GET['hash']) && !empty($_GET['hash'])){
    // Verify data
    $email = $_GET['email']; // Set email variable
    $email = mysqli_real_escape_string($conn,$email);
    $hash = $_GET['hash']; // Set hash variable
    $hash = mysqli_real_escape_string($conn,$hash);


    $query ="SELECT email, hash, active FROM users WHERE email='".$email."' AND hash='".$hash."' AND active='0'";
    $result = mysqli_query($conn,$query);

    if(!$result){

    	die(mysqli_error());
    } 
    $match  = mysqli_num_rows($result);


    if($match > 0){
        // We have a match, activate the account
    	$select = "UPDATE users SET active='1' WHERE email='".$email."' AND hash='".$hash."' AND active='0'";
    	$output = mysqli_query($conn,$select);

    	if(!$output){

    		die(mysqli_error());
    	} else{

    		$msg =  "<div class='alert alert-success alert-dismissable fade in'>Your account has been activated, you can now login<a class='close' data-dismiss='alert'>&times;</a></div>";
    	}
    }else{
        // No match -> invalid url or account has already been activated.
    	$msg = "<div class='alert alert-success alert-dismissable fade in'>The url is either invalid or you already have activated your account<a class='close' data-dismiss='alert'>&times;</a></div>";
    }
}





//Account Activation
if(isset($_POST['verify'])){

   $target = '../uploads/';
   $target2 = '../uploads/';

   include('../includes/upload.php');

   include('../includes/upload2.php');


   $query = "UPDATE users 
   SET `path` = '$fileNameNew',
   `path2` = '$fileNameNew2'
   WHERE `email` = '$email'
   ";
   $result = $conn->query($query);


   if($result === FALSE){
      echo "Error: ".$query."<br>".$conn->error."<br>";
  }else{
  //header("refresh:3;url=signin.php"); 
  }


}
mysqli_close($conn);
?>
<!doctype html>
<!--[if lte IE 9]>     <html lang="en" class="no-focus lt-ie10 lt-ie10-msg"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="en" class="no-focus"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

    <title>Capital Global Market</title>

    <meta name="description" content="Capitalglobalmarket created by pixelcave and published on Themeforest">
    <meta name="author" content="pixelcave">
    <meta name="robots" content="noindex, nofollow">

    <!-- Open Graph Meta -->
    <meta property="og:title" content="Capitalglobalmarket">
    <meta property="og:site_name" content="Capitalglobalmarket">
    <meta property="og:description" content="Capitalglobalmarket created by pixelcave and published on Themeforest">
    <meta property="og:type" content="website">
    <meta property="og:url" content="">
    <meta property="og:image" content="">

    <!-- Icons -->
    <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
    <link rel="shortcut icon" href="../assets/img/favicons/favicon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="../assets/img/favicons/favicon-192x192.png">
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/img/favicons/apple-touch-icon-180x180.png">
    <!-- END Icons -->

    <!-- Stylesheets -->
    <!-- Codebase framework -->
    <link rel="stylesheet" id="css-main" href="../assets/css/codebase.min.css">

    <!-- You can include a specific file from css/themes/ folder to alter the default color theme of the template. eg: -->
    <!-- <link rel="stylesheet" id="css-theme" href="../assets/css/themes/flat.min.css"> -->
    <!-- END Stylesheets -->
</head>
<body>
    <!-- Page Container -->
        <!--
            Available classes for #page-container:

        GENERIC

            'enable-cookies'                            Remembers active color theme between pages (when set through color theme helper Codebase() -> uiHandleTheme())

        SIDEBAR & SIDE OVERLAY

            'sidebar-r'                                 Right Sidebar and left Side Overlay (default is left Sidebar and right Side Overlay)
            'sidebar-mini'                              Mini hoverable Sidebar (screen width > 991px)
            'sidebar-o'                                 Visible Sidebar by default (screen width > 991px)
            'sidebar-o-xs'                              Visible Sidebar by default (screen width < 992px)
            'sidebar-inverse'                           Dark themed sidebar

            'side-overlay-hover'                        Hoverable Side Overlay (screen width > 991px)
            'side-overlay-o'                            Visible Side Overlay by default

            'side-scroll'                               Enables custom scrolling on Sidebar and Side Overlay instead of native scrolling (screen width > 991px)

        HEADER

            ''                                          Static Header if no class is added
            'page-header-fixed'                         Fixed Header

        HEADER STYLE

            ''                                          Classic Header style if no class is added
            'page-header-modern'                        Modern Header style
            'page-header-inverse'                       Dark themed Header (works only with classic Header style)
            'page-header-glass'                         Light themed Header with transparency by default
                                                        (absolute position, perfect for light images underneath - solid light background on scroll if the Header is also set as fixed)
            'page-header-glass page-header-inverse'     Dark themed Header with transparency by default
                                                        (absolute position, perfect for dark images underneath - solid dark background on scroll if the Header is also set as fixed)

        MAIN CONTENT LAYOUT

            ''                                          Full width Main Content if no class is added
            'main-content-boxed'                        Full width Main Content with a specific maximum width (screen width > 1200px)
            'main-content-narrow'                       Full width Main Content with a percentage width (screen width > 1200px)
        -->
        <div id="page-container" class="main-content-boxed">
            <!-- Main Container -->
            <main id="main-container">
                <!-- Page Content -->
                <div class="bg-gd-emerald">
                    <div class="hero-static content content-full bg-white invisible" data-toggle="appear">

                        <!-- Header -->
                        <div class="py-30 px-5 text-center">
                         <?php echo $msg; ?><br>
                         <a class="link-effect font-w700" href="app/">
                            <i class="si si-fire"></i>
                            <span class="font-size-xl text-primary-dark">Capital</span><span class="font-size-xl">Global Market</span>
                        </a>
                        <h1 class="h2 font-w700 mt-50 mb-10">Verify Your Account</h1>
                        <br><br>
                        <label class="alert alert-info">* Please scan and upload the document(s) requested below:<br>
                          Please ensure that the entire document uploaded is visible.<br>
                          The accepted file formats are GIF, JPG, PNG, PDF.
                      The maximum upload file size is 8MB.</label>
                  </div>
                  <!-- END Header -->

                  <!-- Sign Up Form -->
                  <div class="row justify-content-center px-5">
                    <div class="col-sm-8 col-md-6 col-xl-4">
                        <!-- jQuery Validation (.js-validation-signup class is initialized in js/pages/op_auth_signup.js) -->
                        <!-- For more examples you can check out https://github.com/jzaefferer/jquery-validation -->"
                        <form class="js-validation-signup" action="<?php htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data"  method="post">
                            <label>Front Capture</label>
                            <input type="file" class="form-control" name="file">
                            <br>
                            <label>Back Capture</label>
                            <input type="file" class="form-control" name="image">
                            <br><br>
                            <label class="alert-default">A color copy of valid passport or other official state ID (e.g. driver's license, identity card, etc). The ID must be valid and contain the client's full name, an issue or expiry date, the client's place and date of birth OR tax identification number and the client's signature.</label><br>
                            <input type="submit" class="btn btn-info btn-block" name="verify" value="verify">
                        </form>
                    </div>
                </div>
                <!-- END Sign Up Form -->
            </div>
        </div>
        <!-- END Page Content -->
    </main>
    <!-- END Main Container -->
</div>
<!-- END Page Container -->



<!-- Codebase Core JS -->
<script src="../assets/js/core/jquery.min.js"></script>
<script src="../assets/js/core/popper.min.js"></script>
<script src="../assets/js/core/bootstrap.min.js"></script>
<script src="../assets/js/core/jquery.slimscroll.min.js"></script>
<script src="../assets/js/core/jquery.scrollLock.min.js"></script>
<script src="../assets/js/core/jquery.appear.min.js"></script>
<script src="../assets/js/core/jquery.countTo.min.js"></script>
<script src="../assets/js/core/js.cookie.min.js"></script>
<script src="../assets/js/codebase.js"></script>

<!-- Page JS Plugins -->
<script src="../assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>

<!-- Page JS Code -->
<script src="../assets/js/pages/op_auth_signup.js"></script>
</body>
</html>