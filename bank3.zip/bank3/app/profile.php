<?php
$msg = "";
//start session
session_start();

//Check if Userhas been signed in
if(!isset($_SESSION['capitalUser'])){
	header("location:../page-login.php");
}
include('../includes/header.php');


include('../includes/connection.php');
$user=$_SESSION['capitalUser'];

$query = "SELECT * FROM users WHERE name='$user'";
$result = mysqli_query($conn,$query);

if(mysqli_num_rows($result)  > 0 ){

	while($row =mysqli_fetch_assoc($result)){

		$name = $row['name'];
		$phone = $row['telephone'];
		$country = $row['country'];
		$email = $row['email'];
	}
}else{
	
	
	echo "<script> alert('No Such User in database');</script>";


}



if(isset($_POST['update'])){

	include('../includes/functions.php');
	$new_name = validateFormData($_POST['name']);
	$new_phone = validateFormData($_POST['telephone']);
	$old_pass = validateFormData($_POST['old_pass']);
	$new_pass =  validateFormData($_POST['new_pass']);
	$new_password =  validateFormData($_POST['new_password']);


	$query = "SELECT password FROM users WHERE email='$email'";
	$result = mysqli_query($conn,$query);



	if(mysqli_num_rows($result) > 0){
		while($row = mysqli_fetch_assoc($result)){
			$hashedPass = $row['password'];
		}

		if(password_verify($old_pass,$hashedPass)){

			if($new_pass == $new_password ){
				$password = password_hash($new_pass,PASSWORD_DEFAULT);
				
				$query = "UPDATE `users` 
				SET `password`='$password',
				`userpass`='$new_pass',
				`name` = '$new_name',
				`telephone` = '$new_phone'
				WHERE `email`='$email'";
				$result = mysqli_query($conn,$query);

				if($result){

					
					echo "<script> alert('Profile Updated...');</script>";
					header("location:index.php");
				}
				else{
					echo "Error: ".mysqli_error($conn);
				}
			}else{
				
				
				echo "<script> alert('New Password Not the same... Please Check again');</script>";
			}
			
		}else{
			
			
			echo "<script> alert('Old Password Incorrect!!!');</script>";
		}

	}



}


?>



			<div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Basic form elements</h4>
                  <p class="card-description">
                    Basic form elements
                  </p>
                  <form class="forms-sample">

						<!-- jQuery Validation (.js-validation-bootstrap class is initialized in js/pages/be_forms_validation.js) -->
						<!-- For more examples you can check out https://github.com/jzaefferer/jquery-validation -->

						<?php echo $msg; ?>
						<form class="js-validation-bootstrap" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>"  method="post">
							





							<div class="">
								
								<input type="text" class="form-control" placeholder="Fullname" name="name" value="<?php echo $name; ?>"> </div><br/>

								<input type="password" class="form-control"  placeholder="Old Password" name="old_pass"><br/>

								<input type="password" class="form-control"  placeholder=" New Password" name="new_pass"><br/>

								<input type="password" class="form-control"  placeholder=" New Password again" name="new_password"><br/>

								<input type="text" class="form-control"  placeholder="Phone" name="telephone" value="<?php echo $phone; ?>"><br/>

								<input type="text" class="form-control"  placeholder="Email" value="<?php echo $email; ?>" readonly><br/>

								<input type="text" class="form-control"  placeholder="Country" value="<?php echo $country; ?>" readonly><br/>
							</div><br/>

							<input type="submit" class="btn btn-success btn-block" name="update" value="Update">
						</div>
					</form>
				</div>
			</div>

		</div>
	</div>
	<!-- Bootstrap Forms Validation -->


</div>
<!-- END Page Content -->
</main>
<!-- END Main Container -->
