
<?php
$msg= "";
//start session
session_start();

//Check if Userhas been signed in
if(!isset($_SESSION['capitalUser'])){
	header("location:../page-login.php");
}
include('../includes/header.php');


include('../includes/connection.php');

if(isset($_POST['deposit'])){

	if(!empty($_POST['amount']) and !empty($_POST['payment'])){
  //Store Fields in Variables
		$amount = $_POST['amount'];
		$payment = $_POST['payment'];
		$name = $_SESSION['capitalUser'];


    //INSERTION QUERY

		$sql = "INSERT INTO deposit (id,name,amount,payment) VALUES(NULL,'$name','$amount','$payment')";

		if($conn->query($sql) === TRUE){
		    if($payment === "bitcoins"){
		        $msg = "<div class='alert alert-success'>Copy this address to make payment to complete this process 17YAN1AAQVLGsm9177rwMQbdMCS3Y4KEhd <a class='close' data-dismiss='alert'>&times</a></div>";
		    }else{
		       	$msg = "<div class='alert alert-success'>Deposit Successful... <a class='close' data-dismiss='alert'>&times</a></div>";
		    }
		

			include('../includes/d_notify.php');
		}else{
			$msg = "<div class='alert alert-danger'>Error :".$sql.$conn->error."<a class='close' data-dismiss='alert'>&times</a><div>";
		}

	}else{

		$msg = "<div class='alert alert-warning'>Fill Required Fields*<a class='close' data-dismiss='alert'>&times</a></div>";
	}


}


?>

<!-- Main Container -->
<main id="main-container">
	<!-- Page Content -->
	<div class="content">
		<!-- Bootstrap Design -->
		<h2 class="content-heading">Make a Deposit</h2>
		<br><br><br>
		<div class="row center-block">

			<div class="col-md-5">
				<center>	<img src="../img/dep.png"></center>
			</div>
			<div class="col-md-7">
				<!-- Default Elements -->
				<div class="block">
					<div class="block-header block-header-default">
						
						
					</div>
					<div class="block-content">

						<?php echo $msg; ?>
						<form  method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" >
							<div class="form-group row">
								<div class="col-md-12 ">
									<div class="input-group">
										<span class="input-group-addon"><i class="fa fa-money"></i></span>
										<input type="text" class="form-control" id="example-input3-group1"  placeholder=".." name="amount">
										<span class="input-group-addon">.00</span>
									</div>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-md-12 ">
									<select class="form-control" id="example-select" name="payment">
										<option value="1" selected disabled="">Select Payment Options</option>
										<option value="skrill">Skrill</option>
										<option value="neteller">Neteller</option>
										<option value="bitcoins">Bitcoins</option>
											<option value="bank wire">Bank wire</option>
										<option value="moneygram">Money Gram</option>
										<option value="westernunion">Western Union</option>
									</select>
								</div>
							</div>


							<div class="form-group row">
								<div class="col-12">
									<?php
									$username =  $_SESSION['capitalUser'];
										    $chk = mysqli_query($conn,"SELECT * FROM billing where user ='$username' ");
                                            $row = mysqli_num_rows($chk);
                                            if($row == 1){
                                              
                                              ?>
											<button type="submit" class="btn btn-alt-primary btn-block <?=$state?>" name="deposit">Deposit</button>
											<?}else{
										   echo "Please update your billing before transaction can be made";
  
                                            }
                                            		?>
								</div>
							</div>
						</form>
					</div>
				</div>
				<!-- END Default Elements -->
			</div>
			
			
		</div>
		
	</div>
	<!-- END Page Content -->
</main>
<!-- END Main Container -->



<?php
include ('../includes/footer.php');
?>