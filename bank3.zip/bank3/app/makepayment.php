
<?php

//start session
session_start();

//Check if Userhas been signed in
if(!isset($_SESSION['capitalUser'])){
  header("location:../page-login.php");
}
include('../includes/header.php');


include('../includes/connection.php');

?>

<div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Make Payment </h4>
                  <p class="card-description">
                    Basic form elements
                  </p>
                  <form class="forms-sample">


							





							<div class="">
								
								Country of Destination: <input type="text" class="form-control" placeholder="Country of Destination" name="name" value=""> <br/>
								SWIFT/Transit Code: <input type="text" class="form-control" placeholder="SWIFT/Transit Code" name="name" value=""> <br/>
								Bank Account Name: <input type="text" class="form-control" placeholder="Bank Account Name" name="name" value=""> <br/>
								Bank Account Number:<input type="text" class="form-control" placeholder="Bank Account Number" name="name" value=""> <br/>
								Address: <input type="text" class="form-control" placeholder="Address" name="name" value=""> <br/>
								Institution Number (IF APPLICABLE): <input type="text" class="form-control" placeholder="Institution Number (IF APPLICABLE)" name="name" value=""> <br/>
								Amount: <input type="text" class="form-control" placeholder="Amount" name="name" value=""> <br/>
								<input type="submit" class="btn btn-success btn-block" name="update" value="Transfer">
								
				</form>
			</div></div></div></div></div></div></div>