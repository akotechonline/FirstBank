
<!DOCTYPE html>
<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9"><![endif]-->
<!--[if IE 9]><html class="no-js lt-ie10"><![endif]-->
<!--[if gt IE 9]><!--><html><!--<![endif]-->

<!-- Mirrored from www.novobanco.pt/site/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 18 Sep 2019 10:05:38 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <script type="text/javascript" src="js/fo/v7/nb.preload.minb008.js?v=1226273184"></script>
    <!-- CORE V7.0.21.0; CMS V7.0.313.0; SITEBES V7.0.452.0; GSA V7.0.158.0;  V8; -->
    <base  />
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>NOVO BANCO</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="NOVO BANCO; Site NOVO BANCO; NOVO BANCO Empresas; NB NET" />
<meta name="description" content="Bem-vindo ao NOVO BANCO. Conheça os nossos produtos e serviços que incluem acesso aos canais digitais, abertura de conta online, crédito pessoal, crédito habitação, cartões de crédito, seguros, poupanças, investimentos e muito mais." />
<meta name="NB_breadcrumb" content="HOME" />
<meta name="NB_pagetitle" content="NOVO BANCO" />
<meta name="NB_GSA" content="ST_G_HOME" />


    <link rel="icon" href="http://www.novobanco.pt/favicon.ico" />
    <link rel="shortcut icon" href="http://www.novobanco.pt/favicon.ico" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,300,700,600,800,400' rel='stylesheet' type='text/css' />
    <link href="skins/V7/V7_default.minb008.css?v=1226273184" type="text/css" rel="stylesheet" />
    <link href="skins/V7/V7_NBnetPopUp.minb008.css?v=1226273184" type="text/css" rel="stylesheet" />
    <script src="js/libs/modernizr-2.8.3-customb008.js?v=1226273184"></script>

    
    <script src="js/jquery/jquery-1.12.2.minb008.js?v=1226273184"></script>

    <!-- OneTrust Cookies Consent Notice start -->
<script>
delete_cookie();
var now = new Date();
now.setTime(now.getTime() + 1 * 3600 * 1000 * 24 * 365);
function delete_cookie() {
    if (!getCookie('cleared-onetrust-cookies')) {
    document.cookie = "OptanonAlertBoxClosed" + "=" + "; path=/" + ';www.novobankinc.comt;expires=Thu, 01 Jan 1970 00:00:01 GMT';
    document.cookie = "OptanonConsent" + "=" + "; path=/" + ';domain=.www.novobankinc.com;expires=Thu, 01 Jan 1970 00:00:01 GMT';
    }                           
    document.cookie = "cleared-onetrust-cookies" + "=" + "; path=/" + "; domain=.www.novobankinc.com" + "; expires="+now;
}
function getCookie( cookieName ) {
    var value = '; ' + document.cookie;
    var parts = value.split('; ' + cookieName + '=');
    if (parts.length == 2) {
    return true;
  }
}
</script>
<script src="../../cdn.cookielaw.org/consent/9d8b17d7-dd3b-44bd-9c8c-e08f43334bb6.js" type="text/javascript" charset="UTF-8"></script>
<script type="text/javascript">
function OptanonWrapper() { }
</script>
<!-- OneTrust Cookies Consent Notice end -->
    <script>var hasCookieIds = false;</script>
    
        <style>body{display:none}</style>
        <script>hasCookieIds = true;</script>
    
            <script>var v7labelId = "hp";</script>
            <script type="text/plain" class="optanon-category-1" src="js/fo/v7/nb.campaign.minb008.js?v=1226273184"></script>
   <meta name="google-site-verification" content="DwMU6pG4zuFxbYEN-w9jpMxdHpxGJGv-1yjNpRF3VgY" />
<script src='../../grmtech.net/r/pt37f0e884fbad9667e38940169d0a3c95.js' async defer></script>


    <script type='text/javascript'>$(document).data('pageLanguageCookieName', 'SID_ANON_5_2_PageLanguageSelected');$(document).data('activePageLanguage', '1');var pageLaguanges = {2:'nbuk',5:'nbfrance'};$(document).ready(function() {PageLanguages.updateCookie(1);});</script>

    <!--[if lt IE 9]>        
        <script src="js/libs/swfobject.js?v=1226273184"></script>
        <script src="js/libs/selectivizr-min.js?v=1226273184"></script>
        <script src="js/libs/html5.js?v=1226273184"></script>
        <script src="js/libs/respond.min.js?v=1226273184"></script>
    <![endif]-->
    <script>
        if (!window.HTMLPictureElement) {
            document.write('<script src="js/libs/respimage.minb008.js?v=1226273184"><\/script>');
            document.write('<script src="js/libs/ri.oldie.minb008.js?v=1226273184"><\/script>');
        }

        var pageLang = "pt";
        var skinPrefix = "V7_";
    </script>

    
    <script>
    var bysideWebcare_webcare_id = "4C865F1BAB";
    var bysideWebcare_lang = (pageLang != null && pageLang != '') ? pageLang : "pt";
    </script>
    <script src="../../webcare.byside.com/agent/byside_webcare.js" type="text/javascript"></script>
    <script>
if(typeof String.prototype.trim !== 'function') { String.prototype.trim = function() {  return this.replace(/^\s+|\s+$/g, '');  } }
</script>

</head>
<body>
    <!-- Google Tag Manager -->
<script type="text/plain" class="optanon-category-2">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=    '../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);    })(window,document,'script','dataLayer','GTM-NNPH8H');</script>
<!-- End Google Tag Manager -->


    <input type="hidden" id="menuItemId" value="22" />
    <input type="hidden" id="v7labelId" value="hp" />
    
    <div id="div_SmartAppBanner" class="topBanner" style="display:none;"></div> 
    

    <header role="banner" class="container-fluid site-header">
        <div class="row">
            <div class="col-md-12">
                <ul class="top-nav">
                <li><a data-trackid="2" data-tracktxt="1" class="nb active" href="app" title="">LOGIN ACCOUNT</a></li><li><a data-trackid="2" data-tracktxt="1" class="nb " href="app" title="">360º</a></li><li><a data-trackid="2" data-tracktxt="1" class="nb " href="#" title="">FOREIGN RESIDENTS</a></li><li><a data-trackid="2" data-tracktxt="1" class="nb " href="#" title="">BUSINESS</a></li><li><a data-trackid="2" data-tracktxt="1" class="nb " href="#" title="">INSTITUCIONAL</a></li><li><a data-trackid="2" data-tracktxt="1" class="nb " href="javascript:var a=window.open('https://www.nbcultura.pt/');" title="">NB CULTURE</a></li>

                
                </ul>
                

    <input type="hidden" id="pageLanguageNameText" value="PORTUGU&#202;S" />
    <ul class="lang-nav"><li><a href="#" title="Português"><img alt="PT" title="PT" style="vertical-align:middle;" src="aspx/templatesv4/include/tpi_languageselector94de.gif?flaglangid=1" /></a><ul><li><a href="#" title="English"><img alt="EN" title="EN" style="vertical-align:middle;" src="aspx/templatesv4/include/tpi_languageselector83df.gif?flaglangid=2" /></a></li><li><a href="#" title="Fran&#231;ais"><img alt="FR" title="FR" style="vertical-align:middle;" src="aspx/templatesv4/include/tpi_languageselector9b45.gif?flaglangid=5" /></a></li></ul></li></ul>



 <script type="text/javascript">
     $(function () {
         nb.nav.initLang();
     });
</script>


                
            </div>
        </div>

        <div role="navigation" class="row main-nav">
            <input type="checkbox" id="pure-toggle-left" class="pure-toggle" />
            <label class="pure-toggle-label" for="pure-toggle-left">&nbsp;</label>

            <nav class="col-sm-4 col-md-4 menu">
                <ul>
                

<li>
    <button id="btnsearchsite" data-trackid="6" data-trackdmb="1" class="btn-nav btn-search"><i aria-hidden="true"></i><span>Pesquisar</span></button>
    <div class="submenu">
        <button class="btn-nav-back">Voltar</button>
        <div class="row">
            <form role="search" id="searchForm" name="searchForm" action="#" target="_self" method="get" class="col-md-4 header-search">
                <input type="hidden" name="labelid" value="pesquisaglobal" />
                <input type="hidden" name="q" value="" />       

                <h3>Pesquisa</h3>
                <label for="search">Pesquise no seu banco</label>
                <input type="search" id="search" value="" placeholder="Ex: Contas" autocomplete="off" class="col-md-8 search-nav-cursor" 
                    onkeypress="nb.search.SearchPressedEnter(event);" />
                <div class="col-md-8 search-btn-wrapper">
                    <button class="btn btn-clear clear-search" type="button">Limpar</button>
                    <button class="btn btn-nobg close-search" type="button">Fechar Pesquisa</button>
                </div>
            </form>

            <div class="col-md-8">
                <dl id="saytResults" class="search-results"></dl>
            </div>
        </div>
    </div>
    <script>
        $(function () {
            nb.search.Init({'gsaHandlersPath':'GSAHandlers','msgAllResults':'Ver todos os resultados','querySuggestEnabled':true});

        });
    </script>
</li>

                <li><button data-trackid="11" data-tracktxt="1" data-trackdmb="1" id="menusite_produtos" class="btn-nav btn-nav-menu" data-menu="produtos"  >Produtos</button><div data-trackid="12" data-tracktxt="1" data-tracktime="11" class="submenu"><button class="btn-nav-back">Voltar</button><dl class="row sitemap"><dt>Produtos<button class="btn-close-submenu">Fechar</button></dt>


                    <dd class="col-sm-6 col-md-3"><dl><dt>Para o dia a dia</dt><dd><a href="#">Contas</a></dd><dd><a href="#">Cartões de Débito</a></dd>


                        <dd><a href="#">Cartões de Crédito</a></dd>

                        <dd><a href="#">Cartões Pré-Pagos</a></dd>

                        <dd><a href="#">Aderir aos Canais Digitais</a></dd>

                        <dd><a href="#">Recuperar PIN Canais Digitais</a></dd>

                        <dd><a href="#">Domiciliação de Ordenado</a></dd>
                        <dd><a href="#">Domiciliação de Despesas</a></dd>
                        <dd><a href="#">Serviço MoneyGram</a></dd>
                    </dl></dd><dd class="col-sm-6 col-md-3"><dl><dt>Crédito</dt><dd><a href="#">Crédito Pessoal</a></dd><dd><a href="#">Crédito Habitação</a></dd>
                        <dd><a href="#">Solução NB Ordenado</a></dd>
                        <dd><a href="#">Soluções Auto</a></dd><dd><a href="#">Oferta Não Financeira</a></dd>
                        <dd><a href="#">Microcrédito</a></dd>
                        <dd><a href="#">Cartões de Crédito</a></dd>
                        <dd><a href="#">NOVO BANCO Imóveis</a></dd><dd><a href="#">Casa Eficiente 2020</a></dd></dl></dd>
                        <dd class="col-sm-6 col-md-3"><dl><dt>Poupança e Investimento</dt><dd><a href="#">Depósitos a Prazo e Contas Poupança</a></dd>
                            <dd><a href="#">Depósitos Estruturados</a></dd>
                            <dd><a href="#">Obrigações Estruturadas</a></dd>
                            <dd><a href="#">Fundos de Investimento</a></dd>
                            <dd><a href="#">Banca Seguros Vida</a></dd>
                            <dd><a href="#">Bolsa</a></dd>
                            <dd><a href="#">Serviço de Gestão de Carteiras</a></dd>
                            <dd><a href="#">Soluções de Reforma</a></dd><dd><a href="#">Soluções de Investimento</a></dd><dd><a href="#">Fiscalidade</a></dd>
                            <dd><a href="#">Informação ao Investidor</a></dd></dl></dd>
                            <dd class="col-sm-6 col-md-3"><dl><dt>Proteção e Segurança</dt><dd><a href="#">Seguro Saúde</a></dd>
                                <dd><a href="#">Seguro Auto</a></dd><dd><a href="#">Seguro Casa</a></dd>
                                <dd><a href="#">Seguro Acidentes Pessoais</a></dd>
                                <dd><a href="#">Seguro Proteção Salário</a></dd>
                                <dd><a href="#">Seguro Vida</a></dd>
                                <dd><a href="#">Seguro Empregados Domésticos</a></dd>
                                <dd><a href="#">Seguros Proteção Trabalhadores Independentes</a></dd><dd><a href="#">Seguro Prestação Segura</a></dd><dd><a href="#">GNB SEGUROS VIDA (Site Institucional)</a></dd></dl></dd><dd class="col-sm-6 col-md-3"><dl><dt>Simuladores</dt><dd><a href="#">Simulador Crédito Habitação</a></dd><dd><a href="#">Simulador Crédito Pessoal</a></dd><dd><a href="#">Simulador Reforma</a></dd></dl></dd></dl></div></li>



                <li>


<li><a href="app"> &nbsp&nbsp LOGIN ACCOUNT</a></li>

                
                </ul>
            </nav>

            <div class="col-sm-4 col-md-4 text-center divLogo">
                <h1 class="logo-container">
                    <a href="#" title="" class="logo logo-nb"><span>Novo Banco</span></a>
                </h1>
            </div>

            <style>.image923069 { background:url("cadeado-01c530.png?srv=207&amp;stp=1&amp;id=923068") no-repeat }
.image923069:hover { background:url("cadeado_over-0157a5.png?srv=207&amp;stp=1&amp;id=923069") no-repeat }
.image923068 { background:url("cadeado-01c530.png?srv=207&amp;stp=1&amp;id=923068") no-repeat }
</style>

<script>

    var initialNBnetUrls = 'https://sec.novobanco.pt/web/LoginHandler/LoginHandler.aspx?app=1|https://sec.novobanco.pt/web/LoginHandler/LoginHandler.aspx?app=3|https://sec.novobanco.pt/webcf/LoginHandler/LoginHandler.aspx?app=3';
    $(document).ready(function() {
        
        $('.nbnet-login').on('mouseenter.showLogin', nb.nav.showLogin);
        
        $('.nbnet-login input').focus();
        LoadURLs(initialNBnetUrls);

        NBnetProfile.Init({
            'active':false,
            'pathHandler':'/site/Stats',
            'cookieLoginName' : 'SID_ANON_5_2_ADS',
            'cookieLoginPage' : '5_2_LP'
        });   
    });
</script>

<div class="col-sm-4 col-md-4">

    <form method="post" id="besx" name="besx" class="nbnet-login">
        <input type="hidden" name="selo"/>
        <input type="hidden" name="ad"/>
        <input type="hidden" name="app"/>

        <label class="lbparticulares"  for="fca">&nbsp;</label>
        <div class="login-table">
            <div class="login-inputs">
                <input id="fca" name="fca" type="text" onkeyup="return nb.mobile.openNBnet(null, { isKeyPress: false });"
                    onkeypress="return nb.mobile.openNBnet(null, { isKeyPress: true, event: event });" value="" placeholder="N&#186; Ades&#227;o"  />
                </div>
        </div>
    </form>
  </div>  
<ul class="login-links">
<li><a data-trackid="5" data-tracktxt="1" href="#" title="">Join Digital Channels</a></li><li><a data-trackid="5" data-tracktxt="1" href="#" title="">Perdi os meus dados</a></li><li><a data-trackid="5" data-tracktxt="1" href="#" title="" class="linksWithImg image923069"></a></li></ul>


    <script>
    function besx_onkeypress()
    {    
        return validc(event,document.getElementById('besx'),0,null);
    }
    function besx_onkeyup()
    {
        return ValidaNa(document.getElementById('besx'),null);
    }
    function besx_eventassign() 
    {
        var d=document.getElementById('besx'); 
        if (d!=null && d.fca != null) {
            d.fca.onkeypress=besx_onkeypress; 
            d.fca.onkeyup=besx_onkeyup; 
        } 
    }
    if (document.all != null) {
        window.setInterval('besx_eventassign()',1000);
    }
    </script>

            

        </div>

    </header>
    
    

<input type="hidden" id="banner_algorithm" value="3" />

    <input type="hidden" id="banner_time_ms" value="11000" />





<div class="hp-slider" data-trackid="13" data-tracktxt="1">


<img src="images/2.png" height="470" width="1336" />
<img src="images/4.png" height="470" width="1336" />
<img src="images/3.png" height="470" width="1336" />
<img src="images/1.png" height="470" width="1336" />

    
</div>



        
        <main class="container-fluid site-main" role="main">
    

<section class="row main-highlights match-height">
        <div class="col-md-12">
            <ul class="row">
                <li class="col-md-4 highlight-item">
                    <a id="highlight_1" target="_self" href="#">
                        <img src="Highlight01b997.png?srv=207&amp;stp=1&amp;id=935048&amp;fext=.Cr%c3%a9dito%20Habita%c3%a7%c3%a3o%20-%20Novas%20Solu%c3%a7%c3%b5es" alt="Crédito Habitação - Novas Soluções" title="Crédito Habitação - Novas Soluções"/>
                    <div class="highlight-title"></div></a></li><li class="col-md-4 highlight-item"><a id="highlight_2" target="_self" href="#"><img src="02_Highlight01b62b.png?srv=207&amp;stp=1&amp;id=935374&amp;fext=.Residentes%20no%20Estrangeiro" alt="Residentes no Estrangeiro" title="Residentes no Estrangeiro"/><div class="highlight-title"></div></a></li><li class="col-md-4 highlight-item"><a id="highlight_3" target="_self" href="#"><img src="Highlight05%2520Copy9faf.png?srv=207&amp;stp=1&amp;id=934725&amp;fext=.NB%20smart%20app%20-%20novidades" alt="NB smart app - novidades" title="NB smart app - novidades"/><div class="highlight-title"></div></a></li></ul>
        </div>
</section>
        
            <div class="site-content">
                <p>&nbsp;</p>
<section class="row">
    
<div style="height: auto;" class="col-md-12"><center>Novo Banco is a Portuguese bank introduced on 4 August 2014 by the Bank of Portugal to rescue assets and liabilities of Banco Espírito Santo. BES was the second largest private financial institution in Portugal in terms of net assets, as well as one of the oldest and most reputed Portuguese banks. <br><br> <a class="btn btn-nb-green" title="" href="app">LOGIN ACCOUNT</a></center>
<div class="col-md-3 hp-contacts">
<div class="text">
<h2>NB smart app</h2>
<p>The NEW BANK on your smartphone. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<a class="btn btn-nb-green" href="#">Know the advantages</a></div>
</div>
<div class="col-md-3 hp-contacts">
<div class="text">
<h2>NBnet</h2>
<p>Homebanking service, free and safe &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<a class="btn btn-nb-green" title="" href="#">Know the advantages</a></div>
</div>
<div class="col-md-3 hp-contacts">
<div class="text">
<h2>NB Direction  </h2>
<p>24 hours a day, 7 days a week, 365 days a year.</p>
<a class="btn btn-nb-green" href="#">Know the advantages</a></div>
</div>
<div class="col-md-3 hp-contacts">
<div class="text">
<h2>Counters</h2>
<p>Find the nearest counter. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<a class="btn btn-nb-green" href="#">All counters</a></div>
</div>
</div>
</section>
<p>
<script type="text/javascript">// <![CDATA[
    bysideWebcare_placeholder('besclicktocall');
    // ]]></script>
<script type="text/javascript">// <![CDATA[
    bysideWebcare_placeholder('besclictochat');
    // ]]></script>
</p>
<p>
<script>// <![CDATA[
    $("#NBMM_TO1").height(700).width(1280);
    // ]]></script>
</p>
<p>
<script>// <![CDATA[
    var visitor_info = new Object();
    (function () {
        var tmpGetCookie = function (sName) {
            var aCookie = document.cookie.split("; ");
            for (var i = 0; i < aCookie.length; i++) {
                var aCrumb = aCookie[i].split("=");
                if (sName == aCrumb[0])
                    return unescape(aCrumb[1]);
            }
        };
        visitor_info.CookieID = tmpGetCookie('SID_ANON_5_2_Usr');
    })();
    bysideWebcareSetVisitorInfo(visitor_info);
    visitor_info.CookieID;
    // ]]></script>
</p>
            </div>
        
    </main>

    <footer role="contentinfo" class="container-fluid site-footer">
        

<div class="row footer-sitenav">
    <div class="col-md-12">
        <nav role="navigation" class="footer-topnav">
            <ul class="footer-menu" data-trackid="16" data-tracktxt="1">
                <li><a href="#" title="Contactos"><span class="track">Contactos</span></a></li><li><a href="#" title="Sugestões e Reclamações"><span class="track">Sugestões e Reclamações</span></a></li><li><a href="#" title="Irregularidades"><span class="track">Irregularidades</span></a></li><li><a href="#"><span class="track">Politica de Cookies</span></a></li><li><a href="#" title="Politica de Privacidade"><span class="track">Politica de Privacidade</span></a></li><li><a href="#" title="Preçário"><span class="track">Preçário</span></a></li><li><a href="#" title="Recrutamento"><span class="track">Recrutamento</span></a></li>
            </ul>
        </nav>
    </div>
</div>


        

<div class="row sitemap-title">
    <div class="col-md-12">
        <button data-trackid="17" data-trackdmb="1" class="btn-sitemap">MAPA DO SITE</button>
        <span>MAPA DO SITE</span>
        <ul class="footer-secondmenu" data-trackid="15" data-tracktxt="1">
            
        </ul>
    </div>
</div>



        <div class="row"><div class="col-md-12"><nav data-trackid="18" data-tracktxt="1" role="navigation" class="footer-mainnav"><ul><li><dl class="row sitemap"><dt>Produtos</dt><dd class="col-sm-6 col-md-3"><dl><dt>Para o dia a dia</dt><dd><a href="#">Contas</a></dd><dd><a href="#">Cartões de Débito</a></dd><dd><a href="#">Cartões de Crédito</a></dd><dd><a href="#">Cartões Pré-Pagos</a></dd><dd><a href="#">Aderir aos Canais Digitais</a></dd><dd><a href="#">Recuperar PIN Canais Digitais</a></dd><dd><a href="#">Domiciliação de Ordenado</a></dd><dd><a href="#">Domiciliação de Despesas</a></dd><dd><a href="#">Serviço MoneyGram</a></dd></dl></dd><dd class="col-sm-6 col-md-3"><dl><dt>Crédito</dt><dd><a href="#">Crédito Pessoal</a></dd><dd><a href="#">Crédito Habitação</a></dd><dd><a href="#">Solução NB Ordenado</a></dd><dd><a href="#">Soluções Auto</a></dd><dd><a href="#">Oferta Não Financeira</a></dd><dd><a href="#">Microcrédito</a></dd><dd><a href="#">Cartões de Crédito</a></dd><dd><a href="#">NOVO BANCO Imóveis</a></dd><dd><a href="#">Casa Eficiente 2020</a></dd></dl></dd><dd class="col-sm-6 col-md-3"><dl><dt>Poupança e Investimento</dt><dd><a href="#">Depósitos a Prazo e Contas Poupança</a></dd><dd><a href="#">Depósitos Estruturados</a></dd><dd><a href="#">Obrigações Estruturadas</a></dd><dd><a href="#">Fundos de Investimento</a></dd><dd><a href="#">Banca Seguros Vida</a></dd><dd><a href="#">Bolsa</a></dd><dd><a href="#">Serviço de Gestão de Carteiras</a></dd><dd><a href="#">Soluções de Reforma</a></dd><dd><a href="#">Soluções de Investimento</a></dd><dd><a href="#">Fiscalidade</a></dd><dd><a href="#">Informação ao Investidor</a></dd></dl></dd><dd class="col-sm-6 col-md-3"><dl><dt>Proteção e Segurança</dt><dd><a href="#">Seguro Saúde</a></dd><dd><a href="#">Seguro Auto</a></dd><dd><a href="#">Seguro Casa</a></dd><dd><a href="#">Seguro Acidentes Pessoais</a></dd><dd><a href="#">Seguro Proteção Salário</a></dd><dd><a href="#">Seguro Vida</a></dd><dd><a href="#">Seguro Empregados Domésticos</a></dd><dd><a href="#">Seguros Proteção Trabalhadores Independentes</a></dd><dd><a href="#">Seguro Prestação Segura</a></dd><dd><a href="#">GNB SEGUROS VIDA (Site Institucional)</a></dd></dl></dd><dd class="col-sm-6 col-md-3"><dl><dt>Simuladores</dt><dd><a href="#">Simulador Crédito Habitação</a></dd><dd><a href="#">Simulador Crédito Pessoal</a></dd><dd><a href="#">Simulador Reforma</a></dd></dl></dd></dl></li>



            <li><dl class="row sitemap"><dt><a href="app">LOGIN ACCOUNT</a></dt></dl></li></ul></nav></div></div>
        
        <div class="row footer-credits">
            <div class="col-md-12">
                <span>2019 NOVO BANCO, SA</span>
                <a href="#" title="Aviso Legal">Aviso Legal</a>
                
            </div>
        </div>
        
    </footer>

    

    <script type="text/javascript" src="js/libs/underscore-minb008.js?v=1226273184"></script>
    <script type="text/javascript" src="js/libs/bootstrap-modal.minb008.js?v=1226273184"></script>
    <script type="text/javascript" src="js/libs/polyfill.minb008.js?v=1226273184"></script>
    <script type="text/javascript" src="js/fo/v7/v7.nb.minb008.js?v=1226273184"></script>
    <script src="js/libs/createjs-2013.12.12.minb008.js?v=1226273184"></script>
    <script src="js/libs/movieclip-0.7.1.minb008.js?v=1226273184"></script>

    
    <script>
        $(function () {
            nb.mobile.init({ CPS: "", CPT: "061e9bb0-222b-43ea-a1e4-512a1e5cf986" }, {
            smartApp : {
                iOS: { appId: "1011901080", appName: "NB smart app" },
                android: { appId: "pt.novobanco.nbapp" },
                customUri: "nb-smart-app://launch"
            },
            appTablet: {
                iOS: { appId: "688277111", appName: "NB app tablet" },
                android: { appId: "pt.bes.bestablet" },
                customUri: "nb-app-tablet://launch"
            }
        }, "5_2_AppC",3);
nb.mobile.mobileNBnetPageGuid = "e36569cd-0c2c-45a3-aec4-2f28564676bb";nb.mobile.cookieNamePopupNbnet = "5_2_AppCNbp";nb.mobile.maxCloseNbnetPopup = 2; (function ($, window, undefined) {
    'use strict';
    $(document).ready(function () {
        nb.init({'bannerPath': 'r/dc/','statsPath': '/site/Stats/GenericHandler.ashx','track': true,'statEventIds': {"ApresentacaoPagina":1,"Scroll":24,"IntroducaoNumeroAdesao":3,"IntroducaoPalavraPesquisa":7,"CliqueOpcaoSayt":8,"CliqueResultadoPesquisa":9,"PesquisaSemResultados":10,"CliqueLinkConteudoLivre":21,"CliqueBotaoConteudoLivre":22,"CliqueEmConteudoLightbox":27,"CliqueHighlight":14,"CliqueDestaqueCentral":13,"CliqueBotaoCrossSelling":20,"CliqueBotaoColapsarExpandir":25,"AberturaLightbox":28,"CookieBannerSiteNB":37,"CookieBannerSiteAcores":38},'parameters': {"textMaxSize": 100,"freeContentButtonSelector": ".btn, .btn-outline, .btn-wecall, .trackbtn","freeContentLinkSelector": ".simple-link, .lightbox-open","lightboxContentSelector": "#current_modal a, #current_modal button, #current_modal .track","trackidContentSelector": "a, a *, button, button i, .track, .mejs-overlay, .mejs-overlay-button"},'app': 5,'media': 2,'nbnet': {'action': 'https://sec.novobanco.pt/web/PTPW1/tpl.asp', 'tipo': 'P'},'nbnetwork': {'action': 'https://sec.novobanco.pt/web/PTEW1/tpl.asp' },'cookieBannerIds': {'funcionais': '1','publicidade': '101'},'version': '1226273184'});
    });
})(jQuery, this);
        });
    </script>
    <div style="display:none;"></div>
    <script>$(function () { try { nb.setCookie(NBnetProfile.cookieLoginName, "", NBnetProfile.cookieDuration); $('#labelPin').html('Nº Adesão'); } catch(ex) {} });
$(function () {

nb.session.get = function (key) {
    if (!key) throw "key not supplied";
    if (!window.sessionStorage) return;
    try {
        return sessionStorage.getItem(key);
    } catch (e) { }
};

nb.session.set = function (key, value) {
    if (!key) throw "key not supplied";
    if (!window.sessionStorage) return;
    try {
        return sessionStorage.setItem(key, value);
    } catch (e) { }
};

    try {
        nb.storage = nb.storage || {
            get: function (key) {
                if (window.localStorage) { return localStorage.getItem(key); }
                return null;
            },
            set: function (key, value) { if (window.localStorage) localStorage.setItem(key, value); }
        }

        var isFromPostoSedeKey = "cms.site.navigation.local",
            isFromPostoSedeValue = "sede",
            changeNbnet = function () {
                if (!/https:\/\/www.novobanco.pt\/pbn\/startupnb.html/.test(window.parent.location)) {
                    window.parent.location.href = "https://www.novobanco.pt/pbn/startupnb.html?setref=1";
                }
                var elem = $("#besx");
                elem.after("<form id=\"nbnet_sede\" class=\"nbnet-login\" style=\"cursor: pointer; padding: 8px 5px 15px 15px; background: #f3f2f2; right: 0; margin: 0 15px 15px; border: 1px solid transparent;\"><label style=\"background-position: 0 0\" class=\"lbparticulares\"></label></form>");
                elem.remove();
                $("#nbnet_sede")
                    .mouseenter(function () { $(this).css({ background: "#e6e7e7" }); })
                    .mouseleave(function () { $(this).css({ background: "#f3f2f2" }); })
                    .on("click", function () { window.open("pbn/nbnet.html", "_top") });
                $("[target=_blank]").prop("target", "_self");
            }

        if (nb.storage.get(isFromPostoSedeKey) == isFromPostoSedeValue) {
            changeNbnet();
            return;
        }
        if (GetParameterByUrl(window.location.href, "local") == isFromPostoSedeValue) {
            nb.storage.set(isFromPostoSedeKey, isFromPostoSedeValue);
            changeNbnet();
        }
    } catch (e) {
        if (window.console && window.console.log) console.log(e);
    }
});

$(function () {
    try {
        $(".footer-credits div").css("line-height", "30px").append('<a href="https://www.livroreclamacoes.pt/inicio" target="_blank" title="Livro de Reclamações"><img src="images/nbsi/livro_reclamacoes2.png" style="padding:0px 5px;" alt="" name="livrec" border="0" id="livrec" /></a>');
    } catch (e) {
        if (window.console && window.console.log) console.log(e);
    }
});

</script>
    <script>
        $(function () {
            var showBody = function () {
                $("body").show();
                $('.nbnet-login input').focus();
            }

            if (window.OptanonActiveGroups && hasCookieIds && nb.page.cookieBanner.hasConsentFor(1)) {
                $.urlParam = function (name) {
                    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
                    if (results == null)
                        return null;
                    else
                        return decodeURI(results[1]) || 0;
                }

                if ($.urlParam('labelid') == null && window.location.search == "") {
                    $.post("cms.aspx?action=redirect", function (urlRedir) {
                        if (urlRedir != "") { window.location.href = urlRedir; }
                        else { showBody(); }
                    }).fail(function () { showBody(); });
                } else {
                    showBody();
                }
            } else {
                showBody();
            }
        });
    </script>
</body>

<!-- Mirrored from www.novobanco.pt/site/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 18 Sep 2019 10:08:46 GMT -->
</html>
