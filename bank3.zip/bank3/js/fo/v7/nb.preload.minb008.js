﻿var nbPreload={initDate:null,init:function(){nbPreload.initDate=(new Date).getTime()}};nbPreload.init();
//# sourceMappingURL=nb.preload.min.js.map
