﻿
var originalBackgroundImage = "";
var besnetSrvInicial = "11100";

$(document).ready(function () {
    initLinkagemDireta();
});

function initLinkagemDireta(options) {
    var opts = options || {};

    // chave login automatico no NPC
    var sceKey = opts.sceKey;

    // Generate code with all html content div                        
    var buffer = [];
    buffer.push("<div id='modalOverlay'><\/div>");
    buffer.push("<div style='display:none' id='popUpModal'>");
    buffer.push("	<div id='closeButton' onclick='javascript:closeWindow();' onmouseover='javascript:closeButtonOnMouse( this, \"closeButtonHover\");' ><\/div>");
    buffer.push("	<div id='closeButtonHover' onclick='javascript:closeWindow();' onmouseout='javascript:closeButtonOnMouse( this, \"closeButton\");' ><\/div>");
    buffer.push("	<div id='cartao'>");
    buffer.push("		<form method='post' id='besxpopup' name='besxpopup' action=''>");
    buffer.push("			<input type='hidden' name='selo' \/>");
    buffer.push("			<input type='hidden' name='ad' \/>");
    buffer.push("			<input type='hidden' name='app' \/>");
    if (sceKey) buffer.push("<input type='hidden' id='SCE' name='SCE' value='" + sceKey + "'\/>");
    buffer.push("			<input type='hidden' name='LDQSTRING' id='ldqstring' \/>");
    buffer.push("			<input type='hidden' name='srvInicial' id='srvinicial' value='" + besnetSrvInicial + "' \/>");
    buffer.push("			<div" + (sceKey ? " style=\"display:none\"" : "") + " id='divPin'>");
    buffer.push("				<span id='labelPin'>N&ordm; Ades&atilde;o<\/span>");
    buffer.push("               <input id='fca' name='fca' class='inputPin' maxlength='20' size='9' onkeydown='bindNBnetUrls(event);' onkeyup='return ValidaNa(document.getElementById(\"besxpopup\"));' onkeypress='return validc(event,document.getElementById(\"besxpopup\"),0);' \/>");
    buffer.push("			<\/div>");
    if (sceKey) buffer.push("<button id=\"btnNBnetLoginNpc\" class=\"btn btn-nb-green\" style=\"position: absolute; bottom: 10px; width: 90%; left: 5%; right: 5%;\">Entrar</button>");
    buffer.push("		<\/form>");
    buffer.push("	<\/div>");
    buffer.push("<\/div>");
    $("body").append(buffer.join(" "));

    if (sceKey) {
        BESX_action = nb.hp.nbnet.action;

        $("#btnNBnetLoginNpc").on("click", function () {
            $("#fca").trigger($.Event('keypress', { which: 13 /*enter*/ }));
        });
    }

    // Hold original background-image
    originalBackgroundImage = $("#popUpModal #cartao").css("background-image");
}

function initLinkagemDiretaNetwork(options) {
    var opts = options || {};

    // chave login automatico no NPC
    var sceKey = opts.sceKey;

    // Generate code with all html content div                        
    var buffer = [];
    buffer.push("<div id='modalOverlay'><\/div>");
    buffer.push("<div style='display:none' id='popUpModal'>");
    buffer.push("	<div id='closeButton' onclick='javascript:closeWindow();' onmouseover='javascript:closeButtonOnMouse( this, \"closeButtonHover\");' ><\/div>");
    buffer.push("	<div id='closeButtonHover' onclick='javascript:closeWindow();' onmouseout='javascript:closeButtonOnMouse( this, \"closeButton\");' ><\/div>");
    buffer.push("	<div id='cartao'>");
    buffer.push("		<form method='post' id='besxpopup' name='besxpopup' action=''>");
    buffer.push("			<input type='hidden' name='selo' \/>");
    buffer.push("			<input type='hidden' name='ad' \/>");
    buffer.push("			<input type='hidden' name='app' \/>");
    if (sceKey) buffer.push("<input type='hidden' id='SCE' name='SCE' value='" + sceKey + "'\/>");
    buffer.push("			<input type='hidden' name='LDQSTRING' id='ldqstring' \/>");
    buffer.push("			<input type='hidden' name='srvInicial' id='srvinicial' value='" + besnetSrvInicial + "' \/>");
    buffer.push("			<div" + (sceKey ? " style=\"display:none\"" : "") + " id='divPin'>");
    buffer.push("				<span id='labelPin'>N&ordm; Ades&atilde;o<\/span>");
    buffer.push("               <input id='fca' name='fca' class='inputPin' maxlength='20' size='9' onkeydown='bindNBnetUrls(event);' onkeyup='return ValidaNa(document.getElementById(\"besxpopup\"), neg);' onkeypress='return validc(event,document.getElementById(\"besxpopup\"),0,neg);' \/>");
    buffer.push("			<\/div>");
    if (sceKey) buffer.push("<button id=\"btnNBnetworkLoginNpc\" class=\"btn btn-nb-green\" style=\"position: absolute; bottom: 10px; width: 90%; left: 5%; right: 5%;\">Entrar</button>");
    buffer.push("		<\/form>");
    buffer.push("	<\/div>");
    buffer.push("<\/div>");
    $("body").append(buffer.join(" "));

    if (sceKey) {
        BESX_negAction = nb.hp.nbnet.action;

        $("#btnNBnetworkLoginNpc").on("click", function () {
            $("#fca").trigger($.Event('keypress', { which: 13 /*enter*/ }));
        });
    }

    // Hold original background-image
    originalBackgroundImage = $("#popUpModal #cartao").css("background-image");
}

function closeButtonOnMouse(buttonThis, buttonId) {

    buttonThis.style.display = "none";
    document.getElementById(buttonId).style.display = "block";
}

function openWindow(ldqstring, image) {

    window.scrollTo(0, 0);

    document.getElementsByTagName("body")[0].style.overflow = "hidden";

    if (image !== null && image !== 'undefined' && image !== '') {
        $("#popUpModal #cartao").css("background-image", "url('" + image + "')");
    } else {
        document.getElementById("cartao").style.backgroundImage = originalBackgroundImage;
    }

    var btnNBnetLoginNpcButtonElem = $("#btnNBnetLoginNpc"),
        btnNBnetworkLoginNpcButtonElem = $("#btnNBnetworkLoginNpc");

    if (btnNBnetLoginNpcButtonElem.length) {
        $("#besxpopup #ldqstring").val(ldqstring);
        btnNBnetLoginNpcButtonElem.trigger("click");
    } else if (btnNBnetworkLoginNpcButtonElem.length) {
        $("#besxpopup #ldqstring").val(ldqstring);
        btnNBnetworkLoginNpcButtonElem.trigger("click");
    } else {
        $("#popUpModal").show();
        $("#modalOverlay").show();
    }

    openWindow_oncomplete(ldqstring);
}

function closeWindow() {
    $("#popUpModal").hide();
    $("#modalOverlay").hide();
    closeWindow_oncomplete();
}

function closeWindow_oncomplete() {

    document.getElementsByTagName("body")[0].style.overflow = "";
    $("#besxpopup #fca").val("");
}

function openWindow_oncomplete(ldqstring) {

    $("#besxpopup #ldqstring").val(ldqstring);

    var overlayDiv = document.getElementById("modalOverlay");

    var divHeight = getBrowserHeight();
    var divWidth = getBrowserWidth();
    overlayDiv.style.height = divHeight + 'px';
    overlayDiv.style.width = divWidth + 'px';

    SetFocusAtElementPopup(true);
}

function getBrowserWidth() {
    if (self.innerWidth) return self.innerWidth;
    return document.documentElement.offsetWidth;
}

function getBrowserHeight() {
    if (self.innerHeight) return self.innerHeight;
    return document.documentElement.offsetHeight;
}

function SetFocusAtElementPopup(resetCounter) {
    try {
        var aId_Counter = eval('window.Counter_fcapopup');
        if (aId_Counter == null || resetCounter)
            aId_Counter = 0;
        var e = null;
        e = $("#besxpopup :input:visible:enabled:first");
        if (!(e == null || typeof e == "undefined"))
            e.focus();
        if (aId_Counter < 20)
            window.setTimeout('SetFocusAtElementPopup()', 100);
        aId_Counter++;
        eval('window.Counter_fcapopup=' + aId_Counter);

        clearInterval()
    }
    catch (aa) {
        setTimeout('SetFocusAtElementPopup()', 1000);
    }
}
