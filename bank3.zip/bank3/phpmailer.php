<?php


require 'phpmailer/PHPMailerAutoload.php'; // Phpmail package already on server

$mail             = new PHPMailer();

$mail->IsSMTP(); // telling the class to use SMTP
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->Host       = "localhost"; // sets the SMTP server
$mail->Port       = 25;                    // set the SMTP port for the GMAIL server
$mail->Username   = "qservers@binaryoptionslite.org"; // SMTP account username
$mail->Password   = "oGpStPj3pvma";        // SMTP account password

$mail->SetFrom('qservers@binaryoptionslite.org', 'binaryoptionslite.org');
$mail->AddReplyTo("qservers@binaryoptionslite.org","binaryoptionslite.org");
$mail->Subject    = "PHPMailer Test Subject via smtp, basic with authentication";
$mail->MsgHTML("<html><body>This is a sample message! <br></body></html>");
$mail->AddAddress("sprintcorp7@gmail.com");
//$mail->AddAttachment("");      // attachment

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
  // header("Location: http://www.example.com/");
}

 ?>