nbtab = {

	init: function() {
        var $section = $('.tab-icon'),
            $panelWrap = $section.find('.tab-panels'),
			w = $(document).width(),
            isMobile = w < 767;

        window.onresize = function(event) {
            w = $(document).width();
			isMobile = w < 767;

			if(!isMobile){
                $panelWrap.find('.active').removeClass('active');
                $panelWrap.find('.panel').hide();
                $panelWrap.find('button:first-of-type, .panel:first-of-type').addClass('active');
                $panelWrap.find('.panel:first-of-type').show();
			}
        };

        if(isMobile){
            $panelWrap.find('button.active').removeClass('active');
            $panelWrap.find('.panel.active').removeClass('active');
		}

        $section.find('[data-action="gotoPanel"]').on('click', this.toggle);
	},

    toggle: function(e) {
		var $el = $(e.currentTarget),
			$section = $('.tab-icon'),
			$panelWrap = $section.find('.tab-panels'),
			goTo = $el.data('panel'),

            w = $(document).width(),
            isMobile = w < 767;

		if(!$el.hasClass('active')){
            if(!isMobile && $panelWrap.find('.panel.active').length){
                $panelWrap.find('button.active').removeClass('active');
                $panelWrap.find('.panel.active').slideUp(500);
                $panelWrap.find('.panel.active').removeClass('active');
			}

            $el.addClass('active');
            $panelWrap.find('div#'+goTo).slideDown(500);
            $panelWrap.find('div#'+goTo).addClass('active');

		}else{
			if(isMobile){
                $el.removeClass('active');
                $panelWrap.find('div#'+goTo).slideUp(500);
                $panelWrap.find('div#'+goTo).removeClass('active');
            }
		}
	}
	
};