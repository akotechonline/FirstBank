<?php 


//start session
session_start();

//Check if Userhas been signed in
if(isset($_SESSION['capitalUser'])){
  header("location:app/");
}
$msg=$nameError=$emailError=$countryError=$currencyError=$telephoneError = $passError=$message =  null;

$name = $email = $country = $telephone = $currency = "";

if(isset($_POST['register'])){


  include('includes/functions.php');
  if(!$_POST['name']){
    $nameError = "Name cannot be empty";
}else{
    $name = validateFormData($_POST['name']);
}

if(!$_POST['email']){
    $emailError = "E-mail cannot be empty";
}else{
    $email = validateFormData($_POST['email']);
    
}

if(!isset($_POST['country'])){
    $countryError = "Country cannot be empty";
}else{
    $country = validateFormData($_POST['country']);
}

if(!$_POST['phone']){
    $telephoneError = "Telephone cannot be empty";
}else{
    $telephone = validateFormData($_POST['phone']);
}


if(!isset($_POST['currency'])){
    $currencyError = "Currency cannot be empty";
}else{
    $currency = validateFormData($_POST['currency']);
}

if(!$_POST['password']){

    $passError = "Password cannot be empty";
}
else{
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
}

$key = validateFormData($_POST['password']);
$hash = md5( rand(0,1000) ); 
  // Generate random 32 character hash and assign it to a local variable.
// Example output: f4552671f8909587cf485ea990207f3b

//connect to database
include('includes/connection.php');
$query = 'SELECT * FROM users WHERE email = "$email"';
$result = $conn->query($query);

if($result->num_rows > 0){

    $row = $result->fetch_assoc();

    if($email == $row['email']){
      $emailError = "This email address has already been registered. Please provide another email address or log in as an existing user.";
  }

}



if(!empty($name) and !empty($pass) and !empty($email) and !empty($telephone) and !empty($currency) and !empty($country)){
            //make query
    $sql = "INSERT INTO `users`(`id`,`name`,`email`,`telephone`,`country`,`currency`,`password`,`userpass`,`hash`) VALUES(NULL,'$name','$email','$telephone','$country','$currency','$pass','$key','$hash')";

  //check if query is stored
    if($conn->query($sql) === FALSE){
      echo "<div class='alert alert-danger'>Error: ".$query."<br>".$conn->error."</div>";
  }
  else{
      // Return Success - Valid Email

    include('includes/mail.php');
    include('includes/signup_notify.php');

    $message =  "<p class='alert alert-success'>Your account has been made, <br /> please verify it by clicking the activation link that has been send to your email.<a class='close ' data-dismiss='alert'>&times;</a></p>";
    $name = $email = $country = $telephone = $currency = "";
    ?>
    <script> alert('Your account has been created,  please verify it by clicking the activation link that will be sent to your mail or check your spam in less than 4 mins..' 'location:login.php');</script>
    <?php


      //header( "refresh:3;url=signin.php" ); 
     //header('location:signin.php?alert=signup-success');



}
}


}
//close connection 


?>



<!doctype html>
<!--[if lte IE 9]>     <html lang="en" class="no-focus lt-ie10 lt-ie10-msg"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="en" class="no-focus"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

    <title>Register | NOVO BANK PLC</title>

    <meta name="description" content="Capitalglobalmarket created by pixelcave and published on Themeforest">
    <meta name="author" content="pixelcave">
    <meta name="robots" content="noindex, nofollow">

    <!-- Open Graph Meta -->
    <meta property="og:title" content="Capitalglobalmarket">
    <meta property="og:site_name" content="Capitalglobalmarket">
    <meta property="og:description" content="Capitalglobalmarket created by pixelcave and published on Themeforest">
    <meta property="og:type" content="website">
    <meta property="og:url" content="">
    <meta property="og:image" content="">

    <!-- Icons -->
    <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
    <link rel="shortcut icon" href="assets/img/favicons/favicon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/favicons/favicon-192x192.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon-180x180.png">
    <!-- END Icons -->

    <!-- Stylesheets -->
    <!-- Codebase framework -->
    <link rel="stylesheet" id="css-main" href="assets/css/codebase.min.css">

    <!-- You can include a specific file from css/themes/ folder to alter the default color theme of the template. eg: -->
    <!-- <link rel="stylesheet" id="css-theme" href="assets/css/themes/flat.min.css"> -->
    <!-- END Stylesheets -->
</head>
<body>
    <!-- Page Container -->
        <!--
            Available classes for #page-container:

        GENERIC

            'enable-cookies'                            Remembers active color theme between pages (when set through color theme helper Codebase() -> uiHandleTheme())

        SIDEBAR & SIDE OVERLAY

            'sidebar-r'                                 Right Sidebar and left Side Overlay (default is left Sidebar and right Side Overlay)
            'sidebar-mini'                              Mini hoverable Sidebar (screen width > 991px)
            'sidebar-o'                                 Visible Sidebar by default (screen width > 991px)
            'sidebar-o-xs'                              Visible Sidebar by default (screen width < 992px)
            'sidebar-inverse'                           Dark themed sidebar

            'side-overlay-hover'                        Hoverable Side Overlay (screen width > 991px)
            'side-overlay-o'                            Visible Side Overlay by default

            'side-scroll'                               Enables custom scrolling on Sidebar and Side Overlay instead of native scrolling (screen width > 991px)

        HEADER

            ''                                          Static Header if no class is added
            'page-header-fixed'                         Fixed Header

        HEADER STYLE

            ''                                          Classic Header style if no class is added
            'page-header-modern'                        Modern Header style
            'page-header-inverse'                       Dark themed Header (works only with classic Header style)
            'page-header-glass'                         Light themed Header with transparency by default
                                                        (absolute position, perfect for light images underneath - solid light background on scroll if the Header is also set as fixed)
            'page-header-glass page-header-inverse'     Dark themed Header with transparency by default
                                                        (absolute position, perfect for dark images underneath - solid dark background on scroll if the Header is also set as fixed)

        MAIN CONTENT LAYOUT

            ''                                          Full width Main Content if no class is added
            'main-content-boxed'                        Full width Main Content with a specific maximum width (screen width > 1200px)
            'main-content-narrow'                       Full width Main Content with a percentage width (screen width > 1200px)
        -->
        <div id="page-container" class="main-content-boxed">
            <!-- Main Container -->
            <main id="main-container">
                <!-- Page Content -->
                <div class="bg-gd-emerald">
                    <div class="hero-static content content-full bg-white invisible" data-toggle="appear">
                        <!-- Header -->
                        <div class="py-30 px-5 text-center">
                            <a class="link-effect font-w700" href="app/">
                                <i class="si si-fire"></i>
                                <span class="font-size-xl text-primary-dark">NOVO </span><span class="font-size-xl">BANK PLC</span>
                            </a>
                            <h1 class="h2 font-w700 mt-50 mb-10">Create New Account</h1>
                        </div>
                        <!-- END Header -->

                        <!-- Sign Up Form -->
                        <div class="row justify-content-center px-5">
                            <div class="col-sm-8 col-md-6 col-xl-4">
                                <!-- jQuery Validation (.js-validation-signup class is initialized in js/pages/op_auth_signup.js) -->
                                <!-- For more examples you can check out https://github.com/jzaefferer/jquery-validation -->
                                <form class="js-validation-signup"  method="post">
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="signup-username" name="name">
                                                <label for="signup-username">Fullname</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="email" class="form-control" id="signup-email" name="email">
                                                <label for="signup-email">Email</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="text" class="form-control" id="signup-number" name="phone">
                                                <label for="signup-number">Phone Number</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="password" class="form-control" id="signup-password" >
                                                <label for="signup-password">Password</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <input type="password" class="form-control" id="signup-password-confirm" name="password">
                                                <label for="signup-password-confirm">Password Confirmation</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                                <select class="form-control" name="country" id="currency">
                                                  <option value="" selected="selected" disabled="">Select Country</option> 
                                                  <option value="United States">United States</option> 
                                                  <option value="United Kingdom">United Kingdom</option> 
                                                  <option value="Afghanistan">Afghanistan</option> 
                                                  <option value="Albania">Albania</option> 
                                                  <option value="Algeria">Algeria</option> 
                                                  <option value="American Samoa">American Samoa</option> 
                                                  <option value="Andorra">Andorra</option> 
                                                  <option value="Angola">Angola</option> 
                                                  <option value="Anguilla">Anguilla</option> 
                                                  <option value="Antarctica">Antarctica</option> 
                                                  <option value="Antigua and Barbuda">Antigua and Barbuda</option> 
                                                  <option value="Argentina">Argentina</option> 
                                                  <option value="Armenia">Armenia</option> 
                                                  <option value="Aruba">Aruba</option> 
                                                  <option value="Australia">Australia</option> 
                                                  <option value="Austria">Austria</option> 
                                                  <option value="Azerbaijan">Azerbaijan</option> 
                                                  <option value="Bahamas">Bahamas</option> 
                                                  <option value="Bahrain">Bahrain</option> 
                                                  <option value="Bangladesh">Bangladesh</option> 
                                                  <option value="Barbados">Barbados</option> 
                                                  <option value="Belarus">Belarus</option> 
                                                  <option value="Belgium">Belgium</option> 
                                                  <option value="Belize">Belize</option> 
                                                  <option value="Benin">Benin</option> 
                                                  <option value="Bermuda">Bermuda</option> 
                                                  <option value="Bhutan">Bhutan</option> 
                                                  <option value="Bolivia">Bolivia</option> 
                                                  <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option> 
                                                  <option value="Botswana">Botswana</option> 
                                                  <option value="Bouvet Island">Bouvet Island</option> 
                                                  <option value="Brazil">Brazil</option> 
                                                  <option value="British Indian Ocean Territory">British Indian Ocean Territory</option> 
                                                  <option value="Brunei Darussalam">Brunei Darussalam</option> 
                                                  <option value="Bulgaria">Bulgaria</option> 
                                                  <option value="Burkina Faso">Burkina Faso</option> 
                                                  <option value="Burundi">Burundi</option> 
                                                  <option value="Cambodia">Cambodia</option> 
                                                  <option value="Cameroon">Cameroon</option> 
                                                  <option value="Canada">Canada</option> 
                                                  <option value="Cape Verde">Cape Verde</option> 
                                                  <option value="Cayman Islands">Cayman Islands</option> 
                                                  <option value="Central African Republic">Central African Republic</option> 
                                                  <option value="Chad">Chad</option> 
                                                  <option value="Chile">Chile</option> 
                                                  <option value="China">China</option> 
                                                  <option value="Christmas Island">Christmas Island</option> 
                                                  <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option> 
                                                  <option value="Colombia">Colombia</option> 
                                                  <option value="Comoros">Comoros</option> 
                                                  <option value="Congo">Congo</option> 
                                                  <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option> 
                                                  <option value="Cook Islands">Cook Islands</option> 
                                                  <option value="Costa Rica">Costa Rica</option> 
                                                  <option value="Cote D'ivoire">Cote D'ivoire</option> 
                                                  <option value="Croatia">Croatia</option> 
                                                  <option value="Cuba">Cuba</option> 
                                                  <option value="Cyprus">Cyprus</option> 
                                                  <option value="Czech Republic">Czech Republic</option> 
                                                  <option value="Denmark">Denmark</option> 
                                                  <option value="Djibouti">Djibouti</option> 
                                                  <option value="Dominica">Dominica</option> 
                                                  <option value="Dominican Republic">Dominican Republic</option> 
                                                  <option value="Ecuador">Ecuador</option> 
                                                  <option value="Egypt">Egypt</option> 
                                                  <option value="El Salvador">El Salvador</option> 
                                                  <option value="Equatorial Guinea">Equatorial Guinea</option> 
                                                  <option value="Eritrea">Eritrea</option> 
                                                  <option value="Estonia">Estonia</option> 
                                                  <option value="Ethiopia">Ethiopia</option> 
                                                  <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option> 
                                                  <option value="Faroe Islands">Faroe Islands</option> 
                                                  <option value="Fiji">Fiji</option> 
                                                  <option value="Finland">Finland</option> 
                                                  <option value="France">France</option> 
                                                  <option value="French Guiana">French Guiana</option> 
                                                  <option value="French Polynesia">French Polynesia</option> 
                                                  <option value="French Southern Territories">French Southern Territories</option> 
                                                  <option value="Gabon">Gabon</option> 
                                                  <option value="Gambia">Gambia</option> 
                                                  <option value="Georgia">Georgia</option> 
                                                  <option value="Germany">Germany</option> 
                                                  <option value="Ghana">Ghana</option> 
                                                  <option value="Gibraltar">Gibraltar</option> 
                                                  <option value="Greece">Greece</option> 
                                                  <option value="Greenland">Greenland</option> 
                                                  <option value="Grenada">Grenada</option> 
                                                  <option value="Guadeloupe">Guadeloupe</option> 
                                                  <option value="Guam">Guam</option> 
                                                  <option value="Guatemala">Guatemala</option> 
                                                  <option value="Guinea">Guinea</option> 
                                                  <option value="Guinea-bissau">Guinea-bissau</option> 
                                                  <option value="Guyana">Guyana</option> 
                                                  <option value="Haiti">Haiti</option> 
                                                  <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option> 
                                                  <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option> 
                                                  <option value="Honduras">Honduras</option> 
                                                  <option value="Hong Kong">Hong Kong</option> 
                                                  <option value="Hungary">Hungary</option> 
                                                  <option value="Iceland">Iceland</option> 
                                                  <option value="India">India</option> 
                                                  <option value="Indonesia">Indonesia</option> 
                                                  <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option> 
                                                  <option value="Iraq">Iraq</option> 
                                                  <option value="Ireland">Ireland</option> 
                                                  <option value="Israel">Israel</option> 
                                                  <option value="Italy">Italy</option> 
                                                  <option value="Jamaica">Jamaica</option> 
                                                  <option value="Japan">Japan</option> 
                                                  <option value="Jordan">Jordan</option> 
                                                  <option value="Kazakhstan">Kazakhstan</option> 
                                                  <option value="Kenya">Kenya</option> 
                                                  <option value="Kiribati">Kiribati</option> 
                                                  <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option> 
                                                  <option value="Korea, Republic of">Korea, Republic of</option> 
                                                  <option value="Kuwait">Kuwait</option> 
                                                  <option value="Kyrgyzstan">Kyrgyzstan</option> 
                                                  <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option> 
                                                  <option value="Latvia">Latvia</option> 
                                                  <option value="Lebanon">Lebanon</option> 
                                                  <option value="Lesotho">Lesotho</option> 
                                                  <option value="Liberia">Liberia</option> 
                                                  <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option> 
                                                  <option value="Liechtenstein">Liechtenstein</option> 
                                                  <option value="Lithuania">Lithuania</option> 
                                                  <option value="Luxembourg">Luxembourg</option> 
                                                  <option value="Macao">Macao</option> 
                                                  <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option> 
                                                  <option value="Madagascar">Madagascar</option> 
                                                  <option value="Malawi">Malawi</option> 
                                                  <option value="Malaysia">Malaysia</option> 
                                                  <option value="Maldives">Maldives</option> 
                                                  <option value="Mali">Mali</option> 
                                                  <option value="Malta">Malta</option> 
                                                  <option value="Marshall Islands">Marshall Islands</option> 
                                                  <option value="Martinique">Martinique</option> 
                                                  <option value="Mauritania">Mauritania</option> 
                                                  <option value="Mauritius">Mauritius</option> 
                                                  <option value="Mayotte">Mayotte</option> 
                                                  <option value="Mexico">Mexico</option> 
                                                  <option value="Micronesia, Federated States of">Micronesia, Federated States of</option> 
                                                  <option value="Moldova, Republic of">Moldova, Republic of</option> 
                                                  <option value="Monaco">Monaco</option> 
                                                  <option value="Mongolia">Mongolia</option> 
                                                  <option value="Montserrat">Montserrat</option> 
                                                  <option value="Morocco">Morocco</option> 
                                                  <option value="Mozambique">Mozambique</option> 
                                                  <option value="Myanmar">Myanmar</option> 
                                                  <option value="Namibia">Namibia</option> 
                                                  <option value="Nauru">Nauru</option> 
                                                  <option value="Nepal">Nepal</option> 
                                                  <option value="Netherlands">Netherlands</option> 
                                                  <option value="Netherlands Antilles">Netherlands Antilles</option> 
                                                  <option value="New Caledonia">New Caledonia</option> 
                                                  <option value="New Zealand">New Zealand</option> 
                                                  <option value="Nicaragua">Nicaragua</option> 
                                                  <option value="Niger">Niger</option> 
                                                  <option value="Nigeria">Nigeria</option> 
                                                  <option value="Niue">Niue</option> 
                                                  <option value="Norfolk Island">Norfolk Island</option> 
                                                  <option value="Northern Mariana Islands">Northern Mariana Islands</option> 
                                                  <option value="Norway">Norway</option> 
                                                  <option value="Oman">Oman</option> 
                                                  <option value="Pakistan">Pakistan</option> 
                                                  <option value="Palau">Palau</option> 
                                                  <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option> 
                                                  <option value="Panama">Panama</option> 
                                                  <option value="Papua New Guinea">Papua New Guinea</option> 
                                                  <option value="Paraguay">Paraguay</option> 
                                                  <option value="Peru">Peru</option> 
                                                  <option value="Philippines">Philippines</option> 
                                                  <option value="Pitcairn">Pitcairn</option> 
                                                  <option value="Poland">Poland</option> 
                                                  <option value="Portugal">Portugal</option> 
                                                  <option value="Puerto Rico">Puerto Rico</option> 
                                                  <option value="Qatar">Qatar</option> 
                                                  <option value="Reunion">Reunion</option> 
                                                  <option value="Romania">Romania</option> 
                                                  <option value="Russian Federation">Russian Federation</option> 
                                                  <option value="Rwanda">Rwanda</option> 
                                                  <option value="Saint Helena">Saint Helena</option> 
                                                  <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option> 
                                                  <option value="Saint Lucia">Saint Lucia</option> 
                                                  <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option> 
                                                  <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option> 
                                                  <option value="Samoa">Samoa</option> 
                                                  <option value="San Marino">San Marino</option> 
                                                  <option value="Sao Tome and Principe">Sao Tome and Principe</option> 
                                                  <option value="Saudi Arabia">Saudi Arabia</option> 
                                                  <option value="Senegal">Senegal</option> 
                                                  <option value="Serbia and Montenegro">Serbia and Montenegro</option> 
                                                  <option value="Seychelles">Seychelles</option> 
                                                  <option value="Sierra Leone">Sierra Leone</option> 
                                                  <option value="Singapore">Singapore</option> 
                                                  <option value="Slovakia">Slovakia</option> 
                                                  <option value="Slovenia">Slovenia</option> 
                                                  <option value="Solomon Islands">Solomon Islands</option> 
                                                  <option value="Somalia">Somalia</option> 
                                                  <option value="South Africa">South Africa</option> 
                                                  <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option> 
                                                  <option value="Spain">Spain</option> 
                                                  <option value="Sri Lanka">Sri Lanka</option> 
                                                  <option value="Sudan">Sudan</option> 
                                                  <option value="Suriname">Suriname</option> 
                                                  <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option> 
                                                  <option value="Swaziland">Swaziland</option> 
                                                  <option value="Sweden">Sweden</option> 
                                                  <option value="Switzerland">Switzerland</option> 
                                                  <option value="Syrian Arab Republic">Syrian Arab Republic</option> 
                                                  <option value="Taiwan, Province of China">Taiwan, Province of China</option> 
                                                  <option value="Tajikistan">Tajikistan</option> 
                                                  <option value="Tanzania, United Republic of">Tanzania, United Republic of</option> 
                                                  <option value="Thailand">Thailand</option> 
                                                  <option value="Timor-leste">Timor-leste</option> 
                                                  <option value="Togo">Togo</option> 
                                                  <option value="Tokelau">Tokelau</option> 
                                                  <option value="Tonga">Tonga</option> 
                                                  <option value="Trinidad and Tobago">Trinidad and Tobago</option> 
                                                  <option value="Tunisia">Tunisia</option> 
                                                  <option value="Turkey">Turkey</option> 
                                                  <option value="Turkmenistan">Turkmenistan</option> 
                                                  <option value="Turks and Caicos Islands">Turks and Caicos Islands</option> 
                                                  <option value="Tuvalu">Tuvalu</option> 
                                                  <option value="Uganda">Uganda</option> 
                                                  <option value="Ukraine">Ukraine</option> 
                                                  <option value="United Arab Emirates">United Arab Emirates</option> 
                                                  <option value="United Kingdom">United Kingdom</option> 
                                                  <option value="United States">United States</option> 
                                                  <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option> 
                                                  <option value="Uruguay">Uruguay</option> 
                                                  <option value="Uzbekistan">Uzbekistan</option> 
                                                  <option value="Vanuatu">Vanuatu</option> 
                                                  <option value="Venezuela">Venezuela</option> 
                                                  <option value="Viet Nam">Viet Nam</option> 
                                                  <option value="Virgin Islands, British">Virgin Islands, British</option> 
                                                  <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option> 
                                                  <option value="Wallis and Futuna">Wallis and Futuna</option> 
                                                  <option value="Western Sahara">Western Sahara</option> 
                                                  <option value="Yemen">Yemen</option> 
                                                  <option value="Zambia">Zambia</option> 
                                                  <option value="Zimbabwe">Zimbabwe</option>
                                              </select>
                                              <label for="country"Country</label>
                                              </div>
                                          </div>
                                      </div>
                                      <div class="form-group row">
                                        <div class="col-12">
                                            <div class="form-material floating">
                                               <select class="form-control" name="currency" id="currency">
                                                <option disabled="" selected >Select Currency</option>
                                                <option value="USD">USD</option>
                                                <option value="EUR">EUR</option>
                                                <option value="GBP">GBP</option>
                                            </select>
                                            <label for="currency"currency</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row gutters-tiny">
                                        <div class="col-12 mb-10">
                                            <button type="submit" class="btn btn-block btn-hero btn-noborder btn-rounded btn-alt-success" name="register">
                                                <i class="si si-user-follow mr-10"></i> Sign Up
                                            </button>
                                        </div>

                                        
                                    </div>
                                    <div class="block-content bg-body-light">
                                        <div class="form-group text-center">Already Registered?
                                            <a class="link-effect text-muted mr-10 mb-5 d-inline-block" href="page-signup.php"> 
                                                <i class="fa fa-plus mr-5"></i> Sign In
                                            </a>

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- END Sign Up Form -->
                    </div>
                </div>
                <!-- END Page Content -->
            </main>
            <!-- END Main Container -->
        </div>
        <!-- END Page Container -->

        <!-- Terms Modal -->
        <div class="modal fade" id="modal-terms" tabindex="-1" role="dialog" aria-labelledby="modal-terms" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-slidedown" role="document">
                <div class="modal-content">
                    <div class="block block-themed block-transparent mb-0">
                        <div class="block-header bg-primary-dark">
                            <h3 class="block-title">Terms &amp; Conditions</h3>
                            <div class="block-options">
                                <button type="button" class="btn-block-option" data-dismiss="modal" aria-label="Close">
                                    <i class="si si-close"></i>
                                </button>
                            </div>
                        </div>
                        <div class="block-content">
                            <!-- <p>Potenti elit lectus augue eget iaculis vitae etiam, ullamcorper etiam bibendum ad feugiat magna accumsan dolor, nibh molestie cras hac ac ad massa, fusce ante convallis ante urna molestie vulputate bibendum tempus ante justo arcu erat accumsan adipiscing risus, libero condimentum venenatis sit nisl nisi ultricies sed, fames aliquet consectetur consequat nostra molestie neque nullam scelerisque neque commodo turpis quisque etiam egestas vulputate massa, curabitur tellus massa venenatis congue dolor enim integer luctus, nisi suscipit gravida fames quis vulputate nisi viverra luctus id leo dictum lorem, inceptos nibh orci.</p>
                            <p>Potenti elit lectus augue eget iaculis vitae etiam, ullamcorper etiam bibendum ad feugiat magna accumsan dolor, nibh molestie cras hac ac ad massa, fusce ante convallis ante urna molestie vulputate bibendum tempus ante justo arcu erat accumsan adipiscing risus, libero condimentum venenatis sit nisl nisi ultricies sed, fames aliquet consectetur consequat nostra molestie neque nullam scelerisque neque commodo turpis quisque etiam egestas vulputate massa, curabitur tellus massa venenatis congue dolor enim integer luctus, nisi suscipit gravida fames quis vulputate nisi viverra luctus id leo dictum lorem, inceptos nibh orci.</p>
                            <p>Potenti elit lectus augue eget iaculis vitae etiam, ullamcorper etiam bibendum ad feugiat magna accumsan dolor, nibh molestie cras hac ac ad massa, fusce ante convallis ante urna molestie vulputate bibendum tempus ante justo arcu erat accumsan adipiscing risus, libero condimentum venenatis sit nisl nisi ultricies sed, fames aliquet consectetur consequat nostra molestie neque nullam scelerisque neque commodo turpis quisque etiam egestas vulputate massa, curabitur tellus massa venenatis congue dolor enim integer luctus, nisi suscipit gravida fames quis vulputate nisi viverra luctus id leo dictum lorem, inceptos nibh orci.</p> -->
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-alt-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-alt-success" data-dismiss="modal">
                            <i class="fa fa-check"></i> Perfect
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!-- END Terms Modal -->

        <!-- Codebase Core JS -->
        <script src="assets/js/core/jquery.min.js"></script>
        <script src="assets/js/core/popper.min.js"></script>
        <script src="assets/js/core/bootstrap.min.js"></script>
        <script src="assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="assets/js/core/jquery.appear.min.js"></script>
        <script src="assets/js/core/jquery.countTo.min.js"></script>
        <script src="assets/js/core/js.cookie.min.js"></script>
        <script src="assets/js/codebase.js"></script>

        <!-- Page JS Plugins -->
        <script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>

        <!-- Page JS Code -->
        <script src="assets/js/pages/op_auth_signup.js"></script>
    </body>
    </html>